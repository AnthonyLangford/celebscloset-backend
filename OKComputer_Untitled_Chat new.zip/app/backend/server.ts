import express from 'express';
import cors from 'cors';
import mongoose from 'mongoose';
import { createServer } from 'http';
import { Server } from 'socket.io';
import dotenv from 'dotenv';
import cron from 'node-cron';
import path from 'path';
import { fileURLToPath } from 'url';

// Import routes
import authRoutes from './routes/auth.js';
import userRoutes from './routes/users.js';
import postRoutes from './routes/posts.js';
import productRoutes from './routes/products.js';
import messageRoutes from './routes/messages.js';
import reelRoutes from './routes/reels.js';
import eventRoutes from './routes/events.js';
import aiRoutes from './routes/ai.js';
import adminRoutes from './routes/admin.js';
import paymentRoutes from './routes/payments.js';
import celebrityRoutes from './routes/celebrities.js';
import videoRoutes from './routes/videos.js';

// Import models for cleanup tasks
import { Post } from './models/Post.js';
import { Product } from './models/Product.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const httpServer = createServer(app);
const io = new Server(httpServer, {
  cors: {
    origin: process.env.CLIENT_URL || 'http://localhost:3000',
    methods: ['GET', 'POST'],
    credentials: true
  }
});

// Middleware
app.use(cors({
  origin: process.env.CLIENT_URL || 'http://localhost:3000',
  credentials: true
}));
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Static files for uploads
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/posts', postRoutes);
app.use('/api/products', productRoutes);
app.use('/api/messages', messageRoutes);
app.use('/api/reels', reelRoutes);
app.use('/api/events', eventRoutes);
app.use('/api/ai', aiRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/payments', paymentRoutes);
app.use('/api/celebrities', celebrityRoutes);
app.use('/api/videos', videoRoutes);

// MongoDB connection
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/celebscloset';

mongoose.connect(MONGODB_URI)
  .then(() => console.log('✅ Connected to MongoDB'))
  .catch(err => console.error('❌ MongoDB connection error:', err));

// Socket.io for real-time features
const onlineUsers = new Map<string, string>();

io.on('connection', (socket) => {
  console.log('👤 User connected:', socket.id);

  // User comes online
  socket.on('user-online', (userId: string) => {
    onlineUsers.set(userId, socket.id);
    (socket as any).userId = userId;
    io.emit('user-status', { userId, status: 'online' });
  });

  // Join private chat room
  socket.on('join-chat', (chatId: string) => {
    socket.join(chatId);
  });

  // Send message
  socket.on('send-message', (data: { receiverId: string; message: any }) => {
    const { receiverId, message } = data;
    const receiverSocketId = onlineUsers.get(receiverId);
    
    if (receiverSocketId) {
      io.to(receiverSocketId).emit('new-message', message);
    }
    
    socket.emit('message-sent', message);
  });

  // Typing indicator
  socket.on('typing', (data: { receiverId: string; isTyping: boolean }) => {
    const { receiverId, isTyping } = data;
    const receiverSocketId = onlineUsers.get(receiverId);
    
    if (receiverSocketId) {
      io.to(receiverSocketId).emit('user-typing', { 
        userId: (socket as any).userId, 
        isTyping 
      });
    }
  });

  // Video call signaling
  socket.on('call-user', (data: { userToCall: string; signalData: any; from: string; name: string }) => {
    const receiverSocketId = onlineUsers.get(data.userToCall);
    if (receiverSocketId) {
      io.to(receiverSocketId).emit('incoming-call', {
        signal: data.signalData,
        from: data.from,
        name: data.name
      });
    }
  });

  socket.on('answer-call', (data: { to: string; signal: any }) => {
    const callerSocketId = onlineUsers.get(data.to);
    if (callerSocketId) {
      io.to(callerSocketId).emit('call-accepted', data.signal);
    }
  });

  // Notification
  socket.on('send-notification', (data: { receiverId: string; notification: any }) => {
    const { receiverId, notification } = data;
    const receiverSocketId = onlineUsers.get(receiverId);
    
    if (receiverSocketId) {
      io.to(receiverSocketId).emit('notification', notification);
    }
  });

  // Nana AI voice activation
  socket.on('nana-activate', (data: { userId: string }) => {
    socket.emit('nana-ready', { message: 'Hello! I\'m Nana. How can I help you?' });
  });

  // Disconnect
  socket.on('disconnect', () => {
    const userId = (socket as any).userId;
    if (userId) {
      onlineUsers.delete(userId);
      io.emit('user-status', { userId, status: 'offline' });
    }
    console.log('👤 User disconnected:', socket.id);
  });
});

// Scheduled tasks
// Clean up expired stories every hour
cron.schedule('0 * * * *', async () => {
  try {
    await Post.deleteMany({ 
      isStory: true, 
      storyExpiresAt: { $lt: new Date() } 
    });
    console.log('🧹 Cleaned up expired stories');
  } catch (error) {
    console.error('❌ Error cleaning stories:', error);
  }
});

// End expired auctions every minute
cron.schedule('* * * * *', async () => {
  try {
    const expiredAuctions = await Product.find({
      isAuction: true,
      status: 'active',
      auctionEndTime: { $lt: new Date() }
    });

    for (const auction of expiredAuctions) {
      auction.status = 'ended';
      if (auction.highestBidder) {
        auction.status = 'sold';
      }
      await auction.save();
    }
    
    if (expiredAuctions.length > 0) {
      console.log(`🏁 Ended ${expiredAuctions.length} expired auctions`);
    }
  } catch (error) {
    console.error('❌ Error ending auctions:', error);
  }
});

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    timestamp: new Date().toISOString(),
    onlineUsers: onlineUsers.size
  });
});

// Error handling
app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  console.error('❌ Server error:', err);
  res.status(500).json({ error: 'Something went wrong!' });
});

const PORT = process.env.PORT || 5000;

httpServer.listen(PORT, () => {
  console.log(`🚀 CelebsCloset server running on port ${PORT}`);
  console.log(`📡 Socket.io ready for real-time connections`);
});

export { io };
