import mongoose from 'mongoose';

export interface IMessage extends mongoose.Document {
  _id: string;
  senderId: string;
  receiverId: string;
  content: string;
  media?: string;
  mediaType?: 'image' | 'video';
  isRead: boolean;
  createdAt: Date;
}

const messageSchema = new mongoose.Schema({
  senderId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  receiverId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  content: { type: String, required: true },
  media: { type: String },
  mediaType: { type: String, enum: ['image', 'video'] },
  isRead: { type: Boolean, default: false }
}, { timestamps: true });

export const Message = mongoose.model<IMessage>('Message', messageSchema);
