import mongoose from 'mongoose';

export interface ICelebrity extends mongoose.Document {
  _id: string;
  name: string;
  username: string;
  bio: string;
  image: string;
  instagram: string;
  twitter: string;
  facebook: string;
  youtube?: string;
  category: string;
  followers: number;
  isVerified: boolean;
  isActive: boolean;
  netWorth?: string;
  knownFor?: string;
  location?: string;
  createdAt: Date;
}

const celebritySchema = new mongoose.Schema({
  name: { type: String, required: true },
  username: { type: String, required: true, unique: true },
  bio: { type: String, default: '' },
  image: { type: String, default: '' },
  instagram: { type: String, default: '' },
  twitter: { type: String, default: '' },
  facebook: { type: String, default: '' },
  youtube: { type: String, default: '' },
  category: { 
    type: String, 
    enum: ['fashion', 'entertainment', 'sports', 'business', 'music', 'other'],
    default: 'entertainment'
  },
  followers: { type: Number, default: 0 },
  isVerified: { type: Boolean, default: true },
  isActive: { type: Boolean, default: true },
  netWorth: { type: String },
  knownFor: { type: String },
  location: { type: String }
}, { timestamps: true });

export const Celebrity = mongoose.model<ICelebrity>('Celebrity', celebritySchema);
