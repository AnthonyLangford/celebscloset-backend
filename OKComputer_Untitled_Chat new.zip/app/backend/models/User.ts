import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';

export interface IUser extends mongoose.Document {
  _id: string;
  username: string;
  email: string;
  password: string;
  fullName: string;
  avatar: string;
  bio: string;
  isVerified: boolean;
  isCelebrity: boolean;
  isAdmin: boolean;
  isCEO: boolean;
  followers: string[];
  following: string[];
  socialLinks: {
    instagram?: string;
    facebook?: string;
    twitter?: string;
    youtube?: string;
  };
  categories: string[];
  balance: number;
  pendingEarnings: number;
  totalEarnings: number;
  stripeCustomerId?: string;
  stripeConnectId?: string;
  createdAt: Date;
  comparePassword(candidatePassword: string): Promise<boolean>;
}

const userSchema = new mongoose.Schema({
  username: { type: String, required: true, unique: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  fullName: { type: String, required: true },
  avatar: { type: String, default: '' },
  bio: { type: String, default: '' },
  isVerified: { type: Boolean, default: false },
  isCelebrity: { type: Boolean, default: false },
  isAdmin: { type: Boolean, default: false },
  isCEO: { type: Boolean, default: false },
  followers: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  following: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  socialLinks: {
    instagram: String,
    facebook: String,
    twitter: String,
    youtube: String
  },
  categories: [{ type: String }],
  balance: { type: Number, default: 0 },
  pendingEarnings: { type: Number, default: 0 },
  totalEarnings: { type: Number, default: 0 },
  stripeCustomerId: { type: String },
  stripeConnectId: { type: String }
}, { timestamps: true });

userSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, 12);
  next();
});

userSchema.methods.comparePassword = async function(candidatePassword: string): Promise<boolean> {
  return bcrypt.compare(candidatePassword, this.password);
};

export const User = mongoose.model<IUser>('User', userSchema);
