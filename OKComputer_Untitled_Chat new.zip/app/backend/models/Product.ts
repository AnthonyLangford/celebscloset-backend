import mongoose from 'mongoose';

export interface IProduct extends mongoose.Document {
  _id: string;
  sellerId: string;
  title: string;
  description: string;
  price: number;
  category: string;
  subcategory: string;
  images: string[];
  condition: 'new' | 'like-new' | 'good' | 'fair';
  isAuction: boolean;
  auctionEndTime?: Date;
  currentBid?: number;
  highestBidder?: string;
  startingBid?: number;
  status: 'active' | 'sold' | 'ended';
  buyerId?: string;
  createdAt: Date;
}

const productSchema = new mongoose.Schema({
  sellerId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  title: { type: String, required: true },
  description: { type: String, required: true },
  price: { type: Number, required: true },
  category: { 
    type: String, 
    required: true,
    enum: ['fashion', 'accessories', 'entertainment', 'real-estate', 'automotive']
  },
  subcategory: { type: String },
  images: [{ type: String }],
  condition: { 
    type: String, 
    enum: ['new', 'like-new', 'good', 'fair'],
    default: 'good'
  },
  isAuction: { type: Boolean, default: false },
  auctionEndTime: Date,
  currentBid: { type: Number, default: 0 },
  highestBidder: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  startingBid: { type: Number, default: 0 },
  status: { 
    type: String, 
    enum: ['active', 'sold', 'ended'],
    default: 'active'
  },
  buyerId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
}, { timestamps: true });

export const Product = mongoose.model<IProduct>('Product', productSchema);
