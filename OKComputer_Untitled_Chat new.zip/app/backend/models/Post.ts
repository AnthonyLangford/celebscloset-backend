import mongoose from 'mongoose';

export interface IPost extends mongoose.Document {
  _id: string;
  userId: string;
  content: string;
  media: string[];
  mediaType: 'image' | 'video';
  likes: string[];
  comments: {
    _id: string;
    userId: string;
    content: string;
    createdAt: Date;
  }[];
  shares: number;
  isStory: boolean;
  storyExpiresAt?: Date;
  createdAt: Date;
}

const postSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  content: { type: String, default: '' },
  media: [{ type: String }],
  mediaType: { type: String, enum: ['image', 'video'], default: 'image' },
  likes: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  comments: [{
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    content: String,
    createdAt: { type: Date, default: Date.now }
  }],
  shares: { type: Number, default: 0 },
  isStory: { type: Boolean, default: false },
  storyExpiresAt: Date
}, { timestamps: true });

export const Post = mongoose.model<IPost>('Post', postSchema);
