import mongoose from 'mongoose';

export interface IReel extends mongoose.Document {
  _id: string;
  userId: string;
  title: string;
  videoUrl: string;
  thumbnail: string;
  music?: string;
  likes: string[];
  comments: {
    userId: string;
    content: string;
    createdAt: Date;
  }[];
  shares: number;
  views: number;
  isLive: boolean;
  createdAt: Date;
}

const reelSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  title: { type: String, required: true },
  videoUrl: { type: String, required: true },
  thumbnail: { type: String },
  music: { type: String },
  likes: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  comments: [{
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    content: String,
    createdAt: { type: Date, default: Date.now }
  }],
  shares: { type: Number, default: 0 },
  views: { type: Number, default: 0 },
  isLive: { type: Boolean, default: false }
}, { timestamps: true });

export const Reel = mongoose.model<IReel>('Reel', reelSchema);
