import mongoose from 'mongoose';

export interface IEvent extends mongoose.Document {
  _id: string;
  celebrityId: string;
  title: string;
  description: string;
  venue: string;
  date: Date;
  ticketPrice: number;
  totalTickets: number;
  soldTickets: number;
  image: string;
  status: 'upcoming' | 'ongoing' | 'completed';
  createdAt: Date;
}

const eventSchema = new mongoose.Schema({
  celebrityId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  title: { type: String, required: true },
  description: { type: String, required: true },
  venue: { type: String, required: true },
  date: { type: Date, required: true },
  ticketPrice: { type: Number, required: true },
  totalTickets: { type: Number, required: true },
  soldTickets: { type: Number, default: 0 },
  image: { type: String },
  status: { 
    type: String, 
    enum: ['upcoming', 'ongoing', 'completed'],
    default: 'upcoming'
  }
}, { timestamps: true });

export const Event = mongoose.model<IEvent>('Event', eventSchema);
