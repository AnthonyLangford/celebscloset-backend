import mongoose from 'mongoose';

export interface IVideo extends mongoose.Document {
  _id: string;
  userId: string;
  title: string;
  description: string;
  videoUrl: string;
  thumbnail: string;
  s3Key?: string;
  duration: number;
  likes: string[];
  comments: {
    _id: string;
    userId: string;
    content: string;
    createdAt: Date;
  }[];
  shares: number;
  views: number;
  isReel: boolean;
  isStory: boolean;
  createdAt: Date;
}

const videoSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  title: { type: String, required: true },
  description: { type: String, default: '' },
  videoUrl: { type: String, required: true },
  thumbnail: { type: String, default: '' },
  s3Key: { type: String },
  duration: { type: Number, default: 0 },
  likes: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  comments: [{
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    content: String,
    createdAt: { type: Date, default: Date.now }
  }],
  shares: { type: Number, default: 0 },
  views: { type: Number, default: 0 },
  isReel: { type: Boolean, default: false },
  isStory: { type: Boolean, default: false }
}, { timestamps: true });

export const Video = mongoose.model<IVideo>('Video', videoSchema);
