import express from 'express';
import { Reel } from '../models/Reel';
import { auth, AuthRequest } from '../middleware/auth';

const router = express.Router();

// Get all reels
router.get('/', async (req, res) => {
  try {
    const reels = await Reel.find()
      .populate('userId', 'username fullName avatar isVerified')
      .sort({ createdAt: -1 });
    res.json(reels);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Get live reels
router.get('/live', async (req, res) => {
  try {
    const liveReels = await Reel.find({ isLive: true })
      .populate('userId', 'username fullName avatar isVerified');
    res.json(liveReels);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Create reel
router.post('/', auth, async (req: AuthRequest, res) => {
  try {
    const { title, videoUrl, thumbnail, music } = req.body;
    
    const reel = new Reel({
      userId: req.user._id,
      title,
      videoUrl,
      thumbnail,
      music
    });
    
    await reel.save();
    await reel.populate('userId', 'username fullName avatar isVerified');
    res.status(201).json(reel);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Like reel
router.post('/:id/like', auth, async (req: AuthRequest, res) => {
  try {
    const reel = await Reel.findById(req.params.id);
    if (!reel) return res.status(404).json({ error: 'Reel not found' });

    const likeIndex = reel.likes.indexOf(req.user._id);
    if (likeIndex === -1) {
      reel.likes.push(req.user._id);
    } else {
      reel.likes.splice(likeIndex, 1);
    }
    
    await reel.save();
    res.json(reel);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Add view
router.post('/:id/view', async (req, res) => {
  try {
    const reel = await Reel.findById(req.params.id);
    if (!reel) return res.status(404).json({ error: 'Reel not found' });

    reel.views += 1;
    await reel.save();
    res.json(reel);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

export default router;
