import express from 'express';
import { User } from '../models/User';
import { generateToken } from '../middleware/auth';

const router = express.Router();

// Register
router.post('/register', async (req, res) => {
  try {
    const { username, email, password, fullName } = req.body;

    const existingUser = await User.findOne({ $or: [{ email }, { username }] });
    if (existingUser) {
      return res.status(400).json({ error: 'User already exists' });
    }

    const user = new User({ username, email, password, fullName });
    await user.save();

    const token = generateToken(user._id);
    res.status(201).json({
      token,
      user: {
        id: user._id,
        username: user.username,
        email: user.email,
        fullName: user.fullName,
        avatar: user.avatar,
        isVerified: user.isVerified,
        isCelebrity: user.isCelebrity,
        isAdmin: user.isAdmin,
        isCEO: user.isCEO
      }
    });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    const user = await User.findOne({ email });
    if (!user) {
      return res.status(400).json({ error: 'Invalid credentials' });
    }

    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      return res.status(400).json({ error: 'Invalid credentials' });
    }

    const token = generateToken(user._id);
    res.json({
      token,
      user: {
        id: user._id,
        username: user.username,
        email: user.email,
        fullName: user.fullName,
        avatar: user.avatar,
        bio: user.bio,
        isVerified: user.isVerified,
        isCelebrity: user.isCelebrity,
        isAdmin: user.isAdmin,
        isCEO: user.isCEO,
        followers: user.followers,
        following: user.following,
        socialLinks: user.socialLinks,
        balance: user.balance
      }
    });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// CEO Master Login
router.post('/ceo-login', async (req, res) => {
  try {
    const { masterKey } = req.body;
    
    if (masterKey !== process.env.CEO_MASTER_KEY && masterKey !== 'anthony-langford-ceo-2024') {
      return res.status(403).json({ error: 'Invalid master key' });
    }

    let ceo = await User.findOne({ isCEO: true });
    
    if (!ceo) {
      ceo = new User({
        username: 'anthonylangford',
        email: 'ceo@celebscloset.com',
        password: masterKey,
        fullName: 'Anthony Langford',
        isCEO: true,
        isAdmin: true,
        isVerified: true,
        bio: 'CEO & Co-Founder of CelebsCloset'
      });
      await ceo.save();
    }

    const token = generateToken(ceo._id);
    res.json({
      token,
      user: {
        id: ceo._id,
        username: ceo.username,
        email: ceo.email,
        fullName: ceo.fullName,
        avatar: ceo.avatar,
        isCEO: true,
        isAdmin: true
      }
    });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

export default router;
