import express from 'express';
import OpenAI from 'openai';
import { auth, AuthRequest } from '../middleware/auth.js';
import { User } from '../models/User.js';
import { Product } from '../models/Product.js';
import { Video } from '../models/Video.js';
import { Celebrity } from '../models/Celebrity.js';

const router = express.Router();

// Initialize OpenAI
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY || ''
});

// Nana AI Assistant - Voice-enabled search
router.post('/ask', auth, async (req: AuthRequest, res) => {
  try {
    const { question, voiceMode = false } = req.body;
    const lowerQ = question.toLowerCase();
    
    let response: any = {
      answer: '',
      suggestions: [] as string[],
      action: null as string | null,
      data: null as any,
      voiceResponse: ''
    };

    // Celebrity search
    if (lowerQ.includes('celebrity') || lowerQ.includes('star') || lowerQ.includes('famous')) {
      const celebrities = await Celebrity.find({ isActive: true })
        .sort({ followers: -1 })
        .limit(10);
      
      response.answer = `I found ${celebrities.length} celebrities on CelebsCloset! Here are some popular ones:`;
      response.voiceResponse = `I found several celebrities for you. Would you like to see their profiles?`;
      response.suggestions = celebrities.map(c => c.name);
      response.action = 'navigate';
      response.data = { type: 'celebrities', celebrities };
    }
    // Product search
    else if (lowerQ.includes('buy') || lowerQ.includes('shop') || lowerQ.includes('find') || lowerQ.includes('looking for')) {
      let category = null;
      if (lowerQ.includes('fashion')) category = 'fashion';
      else if (lowerQ.includes('accessories')) category = 'accessories';
      else if (lowerQ.includes('entertainment')) category = 'entertainment';
      else if (lowerQ.includes('real estate') || lowerQ.includes('house')) category = 'real-estate';
      else if (lowerQ.includes('car') || lowerQ.includes('auto')) category = 'automotive';
      
      let query: any = { status: 'active' };
      if (category) query.category = category;
      
      const products = await Product.find(query)
        .populate('sellerId', 'username fullName avatar isVerified')
        .limit(5);
      
      if (products.length > 0) {
        response.answer = `I found ${products.length} items for you!`;
        response.voiceResponse = `I found some great items in the ${category || 'marketplace'}. Would you like to see them?`;
        response.suggestions = products.map(p => p.title);
        response.action = 'navigate';
        response.data = { type: 'marketplace', category, products };
      } else {
        response.answer = 'I can help you find items! Try asking about fashion, accessories, entertainment, real estate, or automotive items.';
        response.voiceResponse = 'What type of item are you looking for? I can help you find fashion, accessories, real estate, and more.';
        response.suggestions = ['Show me fashion items', 'Find accessories', 'Browse real estate'];
      }
    }
    // How to sell
    else if (lowerQ.includes('sell') || lowerQ.includes('list') || lowerQ.includes('post item')) {
      response.answer = 'Selling on CelebsCloset is easy! Go to the Marketplace and click "Sell Item". You can list fashion, accessories, entertainment items, real estate, or automotive. We take only 10% commission!';
      response.voiceResponse = 'Selling is easy! Just go to the marketplace and click sell item. You can sell fashion, accessories, real estate, and more with only 10 percent commission.';
      response.suggestions = ['Go to Marketplace', 'How do auctions work?', 'What can I sell?'];
      response.action = 'navigate';
      response.data = { type: 'marketplace', action: 'sell' };
    }
    // Events/Tickets
    else if (lowerQ.includes('event') || lowerQ.includes('ticket') || lowerQ.includes('concert')) {
      response.answer = 'You can find celebrity events and purchase tickets in the Entertainment section. Browse upcoming events and secure your spot!';
      response.voiceResponse = 'Check out the entertainment section for celebrity events and tickets. You can browse and purchase tickets there.';
      response.suggestions = ['Show upcoming events', 'Buy tickets', 'Entertainment feed'];
      response.action = 'navigate';
      response.data = { type: 'entertainment', action: 'events' };
    }
    // Messaging
    else if (lowerQ.includes('message') || lowerQ.includes('chat') || lowerQ.includes('contact')) {
      response.answer = 'You can send private messages to other users! Go to Messages to start chatting.';
      response.voiceResponse = 'You can send private messages through the messages tab. Would you like me to take you there?';
      response.suggestions = ['Go to Messages', 'How to find users?'];
      response.action = 'navigate';
      response.data = { type: 'messages' };
    }
    // Videos/Reels
    else if (lowerQ.includes('video') || lowerQ.includes('reel') || lowerQ.includes('watch')) {
      response.answer = 'Check out the Entertainment section for videos and reels from celebrities and creators!';
      response.voiceResponse = 'You can watch videos and reels in the entertainment section. Would you like to go there now?';
      response.suggestions = ['Watch reels', 'Browse videos', 'Entertainment'];
      response.action = 'navigate';
      response.data = { type: 'entertainment', action: 'reels' };
    }
    // Payment/Money
    else if (lowerQ.includes('payment') || lowerQ.includes('money') || lowerQ.includes('pay') || lowerQ.includes('send money')) {
      response.answer = 'You can send and receive payments through our secure Stripe integration. Go to your profile to manage payments.';
      response.voiceResponse = 'You can send and receive payments securely through our payment system. Check your profile for payment options.';
      response.suggestions = ['View my balance', 'Send payment', 'Payment history'];
      response.action = 'navigate';
      response.data = { type: 'profile', action: 'payments' };
    }
    // Profile
    else if (lowerQ.includes('profile') || lowerQ.includes('account') || lowerQ.includes('my page')) {
      response.answer = 'You can view and edit your profile, see your posts, followers, and manage your settings.';
      response.voiceResponse = 'I can take you to your profile where you can see your posts, followers, and settings.';
      response.action = 'navigate';
      response.data = { type: 'profile' };
    }
    // Greeting
    else if (lowerQ.includes('hello') || lowerQ.includes('hi') || lowerQ.includes('hey') || lowerQ.includes('nana')) {
      response.answer = 'Hello! I\'m Nana, your personal AI assistant on CelebsCloset. How can I help you today?';
      response.voiceResponse = 'Hello! I\'m Nana, your personal assistant. I can help you find products, discover celebrities, sell items, and navigate the app. What would you like to do?';
      response.suggestions = ['Find products', 'Discover celebrities', 'Sell items', 'Watch reels', 'Send a message'];
    }
    // Help/General
    else if (lowerQ.includes('help') || lowerQ.includes('how') || lowerQ.includes('what')) {
      response.answer = 'Hi! I\'m Nana, your AI assistant. I can help you find products, discover celebrities, sell items, buy event tickets, and navigate the app. What would you like to do?';
      response.voiceResponse = 'I can help you with many things on CelebsCloset. I can find products, show you celebrities, help you sell items, and much more. What do you need?';
      response.suggestions = ['Find products', 'Discover celebrities', 'Sell items', 'Get support'];
    }
    // Default - use OpenAI for complex queries
    else {
      try {
        const completion = await openai.chat.completions.create({
          model: 'gpt-3.5-turbo',
          messages: [
            {
              role: 'system',
              content: 'You are Nana, a helpful AI assistant for CelebsCloset, a luxury social commerce platform. Be friendly, concise, and helpful. Keep responses under 100 words.'
            },
            { role: 'user', content: question }
          ],
          max_tokens: 150
        });

        const aiResponse = completion.choices[0]?.message?.content || 'I\'m not sure about that. Can you ask something else?';
        response.answer = aiResponse;
        response.voiceResponse = aiResponse;
        response.suggestions = ['Browse marketplace', 'Find celebrities', 'Watch reels'];
      } catch (aiError) {
        response.answer = 'I\'m Nana, your AI assistant! I can help you find products, discover celebrities, sell items, and navigate CelebsCloset. What are you looking for?';
        response.voiceResponse = 'I can help you find products, celebrities, and navigate the app. What would you like to do?';
        response.suggestions = ['Browse marketplace', 'Find celebrities', 'Sell items', 'Watch reels'];
      }
    }

    res.json(response);
  } catch (error) {
    console.error('AI error:', error);
    res.status(500).json({ 
      error: 'AI service error',
      answer: 'I\'m having trouble right now. Please try again later.',
      voiceResponse: 'I\'m having trouble right now. Please try again later.',
      suggestions: ['Browse marketplace', 'Find celebrities']
    });
  }
});

// Generate voice response using OpenAI TTS
router.post('/speak', auth, async (req: AuthRequest, res) => {
  try {
    const { text } = req.body;
    
    if (!process.env.OPENAI_API_KEY) {
      return res.status(503).json({ error: 'Voice service not available' });
    }

    const mp3 = await openai.audio.speech.create({
      model: 'tts-1',
      voice: 'nova', // Female voice that sounds friendly
      input: text,
    });

    const buffer = Buffer.from(await mp3.arrayBuffer());
    
    res.set('Content-Type', 'audio/mpeg');
    res.send(buffer);
  } catch (error) {
    console.error('TTS error:', error);
    res.status(500).json({ error: 'Failed to generate voice' });
  }
});

// Wake word detection - Nana activation
router.post('/wake', auth, async (req: AuthRequest, res) => {
  try {
    const { audio } = req.body; // Base64 audio data
    
    // Simple wake word detection (in production, use a proper wake word model)
    // For now, we'll just acknowledge the wake
    res.json({
      activated: true,
      message: 'Yes? I\'m listening. How can I help you?',
      voiceResponse: 'Yes? I\'m listening. How can I help you?'
    });
  } catch (error) {
    res.status(500).json({ error: 'Wake detection failed' });
  }
});

// Quick suggestions
router.get('/suggestions', auth, async (req: AuthRequest, res) => {
  try {
    const suggestions = [
      { text: 'Find fashion items', icon: 'Shirt', action: 'marketplace' },
      { text: 'Discover celebrities', icon: 'Star', action: 'celebrities' },
      { text: 'Sell my items', icon: 'Tag', action: 'sell' },
      { text: 'Buy event tickets', icon: 'Ticket', action: 'events' },
      { text: 'Watch live reels', icon: 'Play', action: 'reels' },
      { text: 'Send a message', icon: 'MessageCircle', action: 'messages' },
      { text: 'Check my balance', icon: 'Wallet', action: 'profile' },
      { text: 'View my profile', icon: 'User', action: 'profile' }
    ];
    res.json(suggestions);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

export default router;
