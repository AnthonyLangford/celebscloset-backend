import express from 'express';
import { Post } from '../models/Post';
import { auth, AuthRequest } from '../middleware/auth';

const router = express.Router();

// Get feed posts
router.get('/feed', auth, async (req: AuthRequest, res) => {
  try {
    const posts = await Post.find({ isStory: false })
      .populate('userId', 'username fullName avatar isVerified')
      .populate('comments.userId', 'username fullName avatar')
      .sort({ createdAt: -1 })
      .limit(50);
    res.json(posts);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Get stories
router.get('/stories', auth, async (req: AuthRequest, res) => {
  try {
    const twentyFourHoursAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const stories = await Post.find({ 
      isStory: true, 
      storyExpiresAt: { $gt: new Date() }
    })
      .populate('userId', 'username fullName avatar isVerified isCelebrity')
      .sort({ createdAt: -1 });
    res.json(stories);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Create post
router.post('/', auth, async (req: AuthRequest, res) => {
  try {
    const { content, media, mediaType, isStory } = req.body;
    
    const post = new Post({
      userId: req.user._id,
      content,
      media,
      mediaType,
      isStory,
      storyExpiresAt: isStory ? new Date(Date.now() + 24 * 60 * 60 * 1000) : null
    });
    
    await post.save();
    await post.populate('userId', 'username fullName avatar isVerified');
    res.status(201).json(post);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Like post
router.post('/:id/like', auth, async (req: AuthRequest, res) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ error: 'Post not found' });

    const likeIndex = post.likes.indexOf(req.user._id);
    if (likeIndex === -1) {
      post.likes.push(req.user._id);
    } else {
      post.likes.splice(likeIndex, 1);
    }
    
    await post.save();
    res.json(post);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Add comment
router.post('/:id/comment', auth, async (req: AuthRequest, res) => {
  try {
    const { content } = req.body;
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ error: 'Post not found' });

    post.comments.push({
      userId: req.user._id,
      content,
      createdAt: new Date()
    });
    
    await post.save();
    await post.populate('comments.userId', 'username fullName avatar');
    res.json(post);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Share post
router.post('/:id/share', auth, async (req: AuthRequest, res) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ error: 'Post not found' });

    post.shares += 1;
    await post.save();
    res.json(post);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

export default router;
