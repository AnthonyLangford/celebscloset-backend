import express from 'express';
import { Message } from '../models/Message';
import { auth, AuthRequest } from '../middleware/auth';

const router = express.Router();

// Get conversations
router.get('/conversations', auth, async (req: AuthRequest, res) => {
  try {
    const messages = await Message.find({
      $or: [{ senderId: req.user._id }, { receiverId: req.user._id }]
    })
      .populate('senderId', 'username fullName avatar')
      .populate('receiverId', 'username fullName avatar')
      .sort({ createdAt: -1 });

    // Group by conversation
    const conversations = new Map();
    messages.forEach(msg => {
      const otherId = msg.senderId._id.toString() === req.user._id 
        ? msg.receiverId._id.toString() 
        : msg.senderId._id.toString();
      
      if (!conversations.has(otherId)) {
        conversations.set(otherId, {
          user: msg.senderId._id.toString() === req.user._id ? msg.receiverId : msg.senderId,
          lastMessage: msg,
          unread: 0
        });
      }
      
      if (!msg.isRead && msg.receiverId._id.toString() === req.user._id) {
        conversations.get(otherId).unread++;
      }
    });

    res.json(Array.from(conversations.values()));
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Get messages with user
router.get('/:userId', auth, async (req: AuthRequest, res) => {
  try {
    const messages = await Message.find({
      $or: [
        { senderId: req.user._id, receiverId: req.params.userId },
        { senderId: req.params.userId, receiverId: req.user._id }
      ]
    })
      .populate('senderId', 'username fullName avatar')
      .populate('receiverId', 'username fullName avatar')
      .sort({ createdAt: 1 });

    // Mark messages as read
    await Message.updateMany(
      { senderId: req.params.userId, receiverId: req.user._id, isRead: false },
      { isRead: true }
    );

    res.json(messages);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Send message
router.post('/', auth, async (req: AuthRequest, res) => {
  try {
    const { receiverId, content, media, mediaType } = req.body;
    
    const message = new Message({
      senderId: req.user._id,
      receiverId,
      content,
      media,
      mediaType,
      isRead: false
    });
    
    await message.save();
    await message.populate('senderId', 'username fullName avatar');
    await message.populate('receiverId', 'username fullName avatar');
    
    res.status(201).json(message);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

export default router;
