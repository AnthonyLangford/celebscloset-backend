import express from 'express';
import { User } from '../models/User';
import { Post } from '../models/Post';
import { Product } from '../models/Product';
import { auth, AuthRequest } from '../middleware/auth';

const router = express.Router();

// Get current user
router.get('/me', auth, async (req: AuthRequest, res) => {
  try {
    const user = await User.findById(req.user._id)
      .select('-password')
      .populate('followers', 'username fullName avatar')
      .populate('following', 'username fullName avatar');
    res.json(user);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Get user by username
router.get('/:username', async (req, res) => {
  try {
    const user = await User.findOne({ username: req.params.username })
      .select('-password')
      .populate('followers', 'username fullName avatar')
      .populate('following', 'username fullName avatar');
    
    if (!user) return res.status(404).json({ error: 'User not found' });
    
    const posts = await Post.find({ userId: user._id, isStory: false })
      .populate('userId', 'username fullName avatar isVerified')
      .sort({ createdAt: -1 });
    
    const products = await Product.find({ sellerId: user._id, status: 'active' })
      .populate('sellerId', 'username fullName avatar isVerified')
      .sort({ createdAt: -1 });
    
    res.json({ user, posts, products });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Get celebrities
router.get('/celebrities/all', async (req, res) => {
  try {
    const celebrities = await User.find({ isCelebrity: true })
      .select('-password')
      .sort({ followers: -1 })
      .limit(20);
    res.json(celebrities);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Follow/unfollow user
router.post('/:id/follow', auth, async (req: AuthRequest, res) => {
  try {
    const userToFollow = await User.findById(req.params.id);
    if (!userToFollow) return res.status(404).json({ error: 'User not found' });
    
    if (req.params.id === req.user._id.toString()) {
      return res.status(400).json({ error: 'Cannot follow yourself' });
    }

    const currentUser = await User.findById(req.user._id);
    const followIndex = currentUser!.following.indexOf(req.params.id);
    
    if (followIndex === -1) {
      currentUser!.following.push(req.params.id);
      userToFollow.followers.push(req.user._id);
    } else {
      currentUser!.following.splice(followIndex, 1);
      const followerIndex = userToFollow.followers.indexOf(req.user._id);
      userToFollow.followers.splice(followerIndex, 1);
    }
    
    await currentUser!.save();
    await userToFollow.save();
    
    res.json({ following: currentUser!.following });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Update profile
router.patch('/me', auth, async (req: AuthRequest, res) => {
  try {
    const updates = req.body;
    delete updates.password;
    delete updates.isCEO;
    delete updates.isAdmin;
    
    const user = await User.findByIdAndUpdate(
      req.user._id,
      updates,
      { new: true }
    ).select('-password');
    
    res.json(user);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Search users
router.get('/search/query', async (req, res) => {
  try {
    const { q } = req.query;
    if (!q) return res.json([]);
    
    const users = await User.find({
      $or: [
        { username: { $regex: q, $options: 'i' } },
        { fullName: { $regex: q, $options: 'i' } }
      ]
    })
      .select('-password')
      .limit(20);
    
    res.json(users);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

export default router;
