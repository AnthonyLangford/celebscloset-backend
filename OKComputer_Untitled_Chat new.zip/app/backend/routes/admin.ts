import express from 'express';
import { User } from '../models/User';
import { Product } from '../models/Product';
import { Order } from '../models/Order';
import { Post } from '../models/Post';
import { auth, AuthRequest, requireCEO } from '../middleware/auth';

const router = express.Router();

// Get dashboard stats (CEO only)
router.get('/stats', auth, requireCEO, async (req: AuthRequest, res) => {
  try {
    const totalUsers = await User.countDocuments();
    const totalProducts = await Product.countDocuments();
    const totalOrders = await Order.countDocuments();
    const totalPosts = await Post.countDocuments();
    
    const revenue = await Order.aggregate([
      { $match: { status: { $in: ['paid', 'delivered'] } } },
      { $group: { _id: null, total: { $sum: '$platformFee' } } }
    ]);
    
    const recentOrders = await Order.find()
      .populate('buyerId', 'username fullName')
      .populate('sellerId', 'username fullName')
      .populate('productId', 'title')
      .sort({ createdAt: -1 })
      .limit(10);

    res.json({
      stats: {
        totalUsers,
        totalProducts,
        totalOrders,
        totalPosts,
        totalRevenue: revenue[0]?.total || 0
      },
      recentOrders
    });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Get all users (CEO only)
router.get('/users', auth, requireCEO, async (req: AuthRequest, res) => {
  try {
    const users = await User.find()
      .select('-password')
      .sort({ createdAt: -1 });
    res.json(users);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Verify user (CEO only)
router.post('/users/:id/verify', auth, requireCEO, async (req: AuthRequest, res) => {
  try {
    const user = await User.findByIdAndUpdate(
      req.params.id,
      { isVerified: true },
      { new: true }
    ).select('-password');
    res.json(user);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Make user celebrity (CEO only)
router.post('/users/:id/celebrity', auth, requireCEO, async (req: AuthRequest, res) => {
  try {
    const user = await User.findByIdAndUpdate(
      req.params.id,
      { isCelebrity: true },
      { new: true }
    ).select('-password');
    res.json(user);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Get all products (CEO only)
router.get('/products', auth, requireCEO, async (req: AuthRequest, res) => {
  try {
    const products = await Product.find()
      .populate('sellerId', 'username fullName')
      .sort({ createdAt: -1 });
    res.json(products);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Remove product (CEO only)
router.delete('/products/:id', auth, requireCEO, async (req: AuthRequest, res) => {
  try {
    await Product.findByIdAndDelete(req.params.id);
    res.json({ message: 'Product removed' });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

export default router;
