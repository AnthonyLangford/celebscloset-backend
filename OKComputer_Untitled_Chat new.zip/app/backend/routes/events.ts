import express from 'express';
import { Event } from '../models/Event';
import { Order } from '../models/Order';
import { auth, AuthRequest } from '../middleware/auth';

const router = express.Router();

// Get all events
router.get('/', async (req, res) => {
  try {
    const events = await Event.find()
      .populate('celebrityId', 'username fullName avatar isVerified')
      .sort({ date: 1 });
    res.json(events);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Get upcoming events
router.get('/upcoming', async (req, res) => {
  try {
    const events = await Event.find({ 
      date: { $gte: new Date() },
      status: 'upcoming'
    })
      .populate('celebrityId', 'username fullName avatar isVerified')
      .sort({ date: 1 });
    res.json(events);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Create event (celebrity only)
router.post('/', auth, async (req: AuthRequest, res) => {
  try {
    if (!req.user.isCelebrity && !req.user.isAdmin && !req.user.isCEO) {
      return res.status(403).json({ error: 'Only celebrities can create events' });
    }

    const { title, description, venue, date, ticketPrice, totalTickets, image } = req.body;
    
    const event = new Event({
      celebrityId: req.user._id,
      title,
      description,
      venue,
      date,
      ticketPrice,
      totalTickets,
      image
    });
    
    await event.save();
    await event.populate('celebrityId', 'username fullName avatar isVerified');
    res.status(201).json(event);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Buy ticket
router.post('/:id/buy-ticket', auth, async (req: AuthRequest, res) => {
  try {
    const event = await Event.findById(req.params.id);
    if (!event) return res.status(404).json({ error: 'Event not found' });
    
    if (event.soldTickets >= event.totalTickets) {
      return res.status(400).json({ error: 'Sold out' });
    }

    const platformFee = event.ticketPrice * 0.10;
    const sellerEarnings = event.ticketPrice - platformFee;

    const order = new Order({
      buyerId: req.user._id,
      sellerId: event.celebrityId,
      productId: event._id,
      amount: event.ticketPrice,
      platformFee,
      sellerEarnings,
      status: 'pending'
    });

    event.soldTickets += 1;
    
    await order.save();
    await event.save();

    res.json({ order, event });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

export default router;
