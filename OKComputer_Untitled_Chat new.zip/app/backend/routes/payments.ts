import express from 'express';
import Stripe from 'stripe';
import { auth, AuthRequest, requireCEO } from '../middleware/auth.js';
import { User } from '../models/User.js';
import { Order } from '../models/Order.js';
import { Product } from '../models/Product.js';
import { Event } from '../models/Event.js';
import { v4 as uuidv4 } from 'uuid';

const router = express.Router();

// Initialize Stripe
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || 'sk_test_placeholder', {
  apiVersion: '2024-12-18.acacia'
});

// Get user's balance and payment methods
router.get('/balance', auth, async (req: AuthRequest, res) => {
  try {
    const user = await User.findById(req.user._id);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Get user's Stripe customer ID or create one
    let stripeCustomerId = user.stripeCustomerId;
    
    if (!stripeCustomerId && process.env.STRIPE_SECRET_KEY) {
      const customer = await stripe.customers.create({
        email: user.email,
        name: user.fullName,
        metadata: { userId: user._id.toString() }
      });
      stripeCustomerId = customer.id;
      user.stripeCustomerId = stripeCustomerId;
      await user.save();
    }

    // Get payment methods
    let paymentMethods: any[] = [];
    if (stripeCustomerId && process.env.STRIPE_SECRET_KEY) {
      const methods = await stripe.paymentMethods.list({
        customer: stripeCustomerId,
        type: 'card'
      });
      paymentMethods = methods.data;
    }

    res.json({
      balance: user.balance,
      pendingEarnings: user.pendingEarnings || 0,
      totalEarnings: user.totalEarnings || 0,
      stripeCustomerId,
      paymentMethods
    });
  } catch (error) {
    console.error('Balance error:', error);
    res.status(500).json({ error: 'Failed to fetch balance' });
  }
});

// Add payment method
router.post('/payment-methods', auth, async (req: AuthRequest, res) => {
  try {
    const { paymentMethodId } = req.body;
    const user = await User.findById(req.user._id);
    
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    if (!process.env.STRIPE_SECRET_KEY) {
      return res.status(503).json({ error: 'Payment service not available' });
    }

    // Attach payment method to customer
    let stripeCustomerId = user.stripeCustomerId;
    
    if (!stripeCustomerId) {
      const customer = await stripe.customers.create({
        email: user.email,
        name: user.fullName,
        metadata: { userId: user._id.toString() }
      });
      stripeCustomerId = customer.id;
      user.stripeCustomerId = stripeCustomerId;
    }

    await stripe.paymentMethods.attach(paymentMethodId, {
      customer: stripeCustomerId
    });

    // Set as default payment method
    await stripe.customers.update(stripeCustomerId, {
      invoice_settings: {
        default_payment_method: paymentMethodId
      }
    });

    user.stripeCustomerId = stripeCustomerId;
    await user.save();

    res.json({ message: 'Payment method added successfully' });
  } catch (error: any) {
    console.error('Add payment method error:', error);
    res.status(500).json({ error: error.message || 'Failed to add payment method' });
  }
});

// Create payment intent for purchase
router.post('/create-intent', auth, async (req: AuthRequest, res) => {
  try {
    const { amount, productId, eventId, recipientId } = req.body;
    
    if (!process.env.STRIPE_SECRET_KEY) {
      return res.status(503).json({ error: 'Payment service not available' });
    }

    const user = await User.findById(req.user._id);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Calculate platform fee (10%)
    const platformFee = Math.round(amount * 0.10);
    const sellerAmount = amount - platformFee;

    // Create payment intent
    const paymentIntent = await stripe.paymentIntents.create({
      amount: Math.round(amount * 100), // Convert to cents
      currency: 'usd',
      customer: user.stripeCustomerId,
      automatic_payment_methods: { enabled: true },
      metadata: {
        buyerId: user._id.toString(),
        productId: productId || '',
        eventId: eventId || '',
        recipientId: recipientId || '',
        platformFee: platformFee.toString(),
        sellerAmount: sellerAmount.toString()
      }
    });

    res.json({
      clientSecret: paymentIntent.client_secret,
      paymentIntentId: paymentIntent.id
    });
  } catch (error: any) {
    console.error('Create intent error:', error);
    res.status(500).json({ error: error.message || 'Failed to create payment intent' });
  }
});

// Send money to another user
router.post('/send', auth, async (req: AuthRequest, res) => {
  try {
    const { recipientId, amount, note } = req.body;
    
    const sender = await User.findById(req.user._id);
    const recipient = await User.findById(recipientId);
    
    if (!sender || !recipient) {
      return res.status(404).json({ error: 'User not found' });
    }

    if (sender.balance < amount) {
      return res.status(400).json({ error: 'Insufficient balance' });
    }

    // Deduct from sender
    sender.balance -= amount;
    await sender.save();

    // Add to recipient
    recipient.balance += amount;
    await recipient.save();

    // Create transaction record
    const transaction = {
      _id: uuidv4(),
      senderId: sender._id,
      recipientId: recipient._id,
      amount,
      note: note || '',
      type: 'transfer',
      status: 'completed',
      createdAt: new Date()
    };

    res.json({
      message: 'Payment sent successfully',
      transaction,
      newBalance: sender.balance
    });
  } catch (error) {
    console.error('Send payment error:', error);
    res.status(500).json({ error: 'Failed to send payment' });
  }
});

// Request money from another user
router.post('/request', auth, async (req: AuthRequest, res) => {
  try {
    const { requesteeId, amount, note } = req.body;
    
    const requester = await User.findById(req.user._id);
    const requestee = await User.findById(requesteeId);
    
    if (!requester || !requestee) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Create payment request
    const request = {
      _id: uuidv4(),
      requesterId: requester._id,
      requesteeId: requestee._id,
      amount,
      note: note || '',
      status: 'pending',
      createdAt: new Date()
    };

    res.json({
      message: 'Payment request sent',
      request
    });
  } catch (error) {
    console.error('Request payment error:', error);
    res.status(500).json({ error: 'Failed to request payment' });
  }
});

// Accept payment request
router.post('/accept-request/:requestId', auth, async (req: AuthRequest, res) => {
  try {
    const { requestId } = req.params;
    
    // In production, fetch request from database
    // For now, simulate acceptance
    
    res.json({
      message: 'Payment request accepted',
      requestId
    });
  } catch (error) {
    console.error('Accept request error:', error);
    res.status(500).json({ error: 'Failed to accept request' });
  }
});

// Withdraw funds to bank account
router.post('/withdraw', auth, async (req: AuthRequest, res) => {
  try {
    const { amount, bankAccountId } = req.body;
    
    const user = await User.findById(req.user._id);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    if (user.balance < amount) {
      return res.status(400).json({ error: 'Insufficient balance' });
    }

    if (!process.env.STRIPE_SECRET_KEY) {
      return res.status(503).json({ error: 'Payment service not available' });
    }

    // Create transfer to connected account
    // In production, user would have a connected Stripe account
    
    // Deduct from balance
    user.balance -= amount;
    await user.save();

    res.json({
      message: 'Withdrawal initiated',
      amount,
      newBalance: user.balance
    });
  } catch (error) {
    console.error('Withdraw error:', error);
    res.status(500).json({ error: 'Failed to withdraw' });
  }
});

// Get transaction history
router.get('/transactions', auth, async (req: AuthRequest, res) => {
  try {
    // Fetch orders where user is buyer or seller
    const orders = await Order.find({
      $or: [
        { buyerId: req.user._id },
        { sellerId: req.user._id }
      ]
    })
      .populate('buyerId', 'username fullName avatar')
      .populate('sellerId', 'username fullName avatar')
      .populate('productId', 'title images')
      .sort({ createdAt: -1 })
      .limit(50);

    res.json(orders);
  } catch (error) {
    console.error('Transactions error:', error);
    res.status(500).json({ error: 'Failed to fetch transactions' });
  }
});

// Webhook for Stripe events
router.post('/webhook', express.raw({ type: 'application/json' }), async (req, res) => {
  const sig = req.headers['stripe-signature'];
  const endpointSecret = process.env.STRIPE_WEBHOOK_SECRET;

  try {
    let event;
    
    if (endpointSecret && sig) {
      event = stripe.webhooks.constructEvent(req.body, sig, endpointSecret);
    } else {
      event = JSON.parse(req.body.toString());
    }

    // Handle payment success
    if (event.type === 'payment_intent.succeeded') {
      const paymentIntent = event.data.object;
      const { buyerId, productId, eventId, recipientId, sellerAmount } = paymentIntent.metadata;

      // Update order status
      if (productId) {
        await Order.findOneAndUpdate(
          { paymentIntentId: paymentIntent.id },
          { status: 'paid' }
        );

        // Update product status
        await Product.findByIdAndUpdate(productId, { status: 'sold' });

        // Add to seller's balance
        if (sellerAmount) {
          const seller = await User.findById(recipientId);
          if (seller) {
            seller.balance += parseInt(sellerAmount);
            seller.totalEarnings = (seller.totalEarnings || 0) + parseInt(sellerAmount);
            await seller.save();
          }
        }
      }

      // Handle event ticket purchase
      if (eventId) {
        await Event.findByIdAndUpdate(eventId, {
          $inc: { soldTickets: 1 }
        });
      }
    }

    res.json({ received: true });
  } catch (error: any) {
    console.error('Webhook error:', error);
    res.status(400).json({ error: error.message });
  }
});

// Get platform earnings (CEO only)
router.get('/platform-earnings', auth, requireCEO, async (req: AuthRequest, res) => {
  try {
    const orders = await Order.find({ status: { $in: ['paid', 'delivered'] } });
    
    const totalEarnings = orders.reduce((sum, order) => sum + order.platformFee, 0);
    const totalSales = orders.reduce((sum, order) => sum + order.amount, 0);

    res.json({
      totalEarnings,
      totalSales,
      totalOrders: orders.length,
      platformFeeRate: 0.10
    });
  } catch (error) {
    console.error('Platform earnings error:', error);
    res.status(500).json({ error: 'Failed to fetch platform earnings' });
  }
});

export default router;
