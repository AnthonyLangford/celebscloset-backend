import express from 'express';
import authRoutes from './auth';
import userRoutes from './users';
import postRoutes from './posts';
import productRoutes from './products';
import messageRoutes from './messages';
import reelRoutes from './reels';
import eventRoutes from './events';
import aiRoutes from './ai';
import adminRoutes from './admin';
import paymentRoutes from './payments';

const router = express.Router();

router.use('/auth', authRoutes);
router.use('/users', userRoutes);
router.use('/posts', postRoutes);
router.use('/products', productRoutes);
router.use('/messages', messageRoutes);
router.use('/reels', reelRoutes);
router.use('/events', eventRoutes);
router.use('/ai', aiRoutes);
router.use('/admin', adminRoutes);
router.use('/payments', paymentRoutes);

export default router;
