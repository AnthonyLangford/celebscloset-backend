import express from 'express';
import { Celebrity } from '../models/Celebrity.js';
import { auth } from '../middleware/auth.js';
import axios from 'axios';

const router = express.Router();

// Real celebrity data - curated list of American celebrities
const REAL_CELEBRITIES = [
  {
    name: 'Kim Kardashian',
    username: 'kimkardashian',
    bio: 'CEO of SKIMS, KKW Beauty, and Kardashian-Jenner family member. Fashion icon and entrepreneur.',
    instagram: 'https://instagram.com/kimkardashian',
    twitter: 'https://twitter.com/KimKardashian',
    facebook: 'https://facebook.com/KimKardashian',
    image: 'https://upload.wikimedia.org/wikipedia/commons/e/e2/Kim_Kardashian_2019.jpg',
    category: 'fashion',
    followers: 364000000,
    isVerified: true,
    netWorth: '$1.2 Billion',
    knownFor: 'Reality TV Star, Entrepreneur',
    location: 'Los Angeles, CA'
  },
  {
    name: 'Kylie Jenner',
    username: 'kyliejenner',
    bio: 'Founder of Kylie Cosmetics. Youngest self-made billionaire. Beauty and fashion mogul.',
    instagram: 'https://instagram.com/kyliejenner',
    twitter: 'https://twitter.com/KylieJenner',
    facebook: 'https://facebook.com/KylieJenner',
    image: 'https://upload.wikimedia.org/wikipedia/commons/6/65/Kylie_Jenner_in_2021.jpg',
    category: 'fashion',
    followers: 399000000,
    isVerified: true,
    netWorth: '$750 Million',
    knownFor: 'Cosmetics Entrepreneur, Model',
    location: 'Los Angeles, CA'
  },
  {
    name: 'Dwayne Johnson',
    username: 'therock',
    bio: 'The Rock. Actor, producer, and former professional wrestler. Founder of Teremana Tequila.',
    instagram: 'https://instagram.com/therock',
    twitter: 'https://twitter.com/TheRock',
    facebook: 'https://facebook.com/DwayneJohnson',
    image: 'https://upload.wikimedia.org/wikipedia/commons/f/f1/Dwayne_Johnson_2%2C_2013.jpg',
    category: 'entertainment',
    followers: 389000000,
    isVerified: true,
    netWorth: '$800 Million',
    knownFor: 'Actor, Producer, Former WWE Star',
    location: 'Los Angeles, CA'
  },
  {
    name: 'Beyoncé',
    username: 'beyonce',
    bio: 'Queen Bey. Singer, songwriter, actress, and entrepreneur. Founder of Ivy Park.',
    instagram: 'https://instagram.com/beyonce',
    twitter: 'https://twitter.com/Beyonce',
    facebook: 'https://facebook.com/beyonce',
    image: 'https://upload.wikimedia.org/wikipedia/commons/3/3f/Beyonc%C3%A9_-_Tottenham_Hotspur_Stadium_-_1st_June_2023_%2810_of_118%29_%2852945863635%29_%28cropped_2%29.jpg',
    category: 'entertainment',
    followers: 318000000,
    isVerified: true,
    netWorth: '$540 Million',
    knownFor: 'Singer, Songwriter, Businesswoman',
    location: 'Los Angeles, CA'
  },
  {
    name: 'Cristiano Ronaldo',
    username: 'cristiano',
    bio: 'Football legend. 5-time Ballon d\'Or winner. Entrepreneur and philanthropist.',
    instagram: 'https://instagram.com/cristiano',
    twitter: 'https://twitter.com/Cristiano',
    facebook: 'https://facebook.com/Cristiano',
    image: 'https://upload.wikimedia.org/wikipedia/commons/8/8c/Cristiano_Ronaldo_2018.jpg',
    category: 'sports',
    followers: 600000000,
    isVerified: true,
    netWorth: '$500 Million',
    knownFor: 'Professional Footballer',
    location: 'Riyadh, Saudi Arabia'
  },
  {
    name: 'Taylor Swift',
    username: 'taylorswift',
    bio: 'Singer-songwriter. 14-time Grammy winner. Record-breaking artist and advocate.',
    instagram: 'https://instagram.com/taylorswift',
    twitter: 'https://twitter.com/taylorswift13',
    facebook: 'https://facebook.com/TaylorSwift',
    image: 'https://upload.wikimedia.org/wikipedia/commons/b/b5/191125_Taylor_Swift_at_the_2019_American_Music_Awards.png',
    category: 'entertainment',
    followers: 272000000,
    isVerified: true,
    netWorth: '$1.1 Billion',
    knownFor: 'Singer-Songwriter',
    location: 'New York, NY'
  },
  {
    name: 'LeBron James',
    username: 'kingjames',
    bio: '4-time NBA Champion. Entrepreneur, philanthropist, and actor. More Than An Athlete.',
    instagram: 'https://instagram.com/kingjames',
    twitter: 'https://twitter.com/KingJames',
    facebook: 'https://facebook.com/LeBron',
    image: 'https://upload.wikimedia.org/wikipedia/commons/c/cf/LeBron_James_crop.jpg',
    category: 'sports',
    followers: 159000000,
    isVerified: true,
    netWorth: '$1 Billion',
    knownFor: 'NBA Superstar, Entrepreneur',
    location: 'Los Angeles, CA'
  },
  {
    name: 'Selena Gomez',
    username: 'selenagomez',
    bio: 'Actress, singer, and producer. Founder of Rare Beauty. Mental health advocate.',
    instagram: 'https://instagram.com/selenagomez',
    twitter: 'https://twitter.com/selenagomez',
    facebook: 'https://facebook.com/Selena',
    image: 'https://upload.wikimedia.org/wikipedia/commons/8/85/Selena_Gomez_-_Walmart_Soundcheck_Concert.jpg',
    category: 'entertainment',
    followers: 429000000,
    isVerified: true,
    netWorth: '$800 Million',
    knownFor: 'Actress, Singer, Producer',
    location: 'Los Angeles, CA'
  },
  {
    name: 'Ariana Grande',
    username: 'arianagrande',
    bio: 'Singer, songwriter, and actress. Grammy winner. R.E.M. Beauty founder.',
    instagram: 'https://instagram.com/arianagrande',
    twitter: 'https://twitter.com/ArianaGrande',
    facebook: 'https://facebook.com/arianagrande',
    image: 'https://upload.wikimedia.org/wikipedia/commons/d/dd/Ariana_Grande_Grammys_Red_Carpet_2020.png',
    category: 'entertainment',
    followers: 380000000,
    isVerified: true,
    netWorth: '$240 Million',
    knownFor: 'Singer, Actress',
    location: 'Los Angeles, CA'
  },
  {
    name: 'Drake',
    username: 'champagnepapi',
    bio: 'Rapper, singer, and songwriter. OVO Sound founder. Certified Lover Boy.',
    instagram: 'https://instagram.com/champagnepapi',
    twitter: 'https://twitter.com/Drake',
    facebook: 'https://facebook.com/Drake',
    image: 'https://upload.wikimedia.org/wikipedia/commons/2/22/Drake_-_V Festival_2014_%28cropped%29.jpg',
    category: 'entertainment',
    followers: 143000000,
    isVerified: true,
    netWorth: '$250 Million',
    knownFor: 'Rapper, Singer, Songwriter',
    location: 'Toronto, Canada'
  },
  {
    name: 'Rihanna',
    username: 'badgalriri',
    bio: 'Singer, businesswoman, and fashion designer. Fenty Beauty and Savage X Fenty founder.',
    instagram: 'https://instagram.com/badgalriri',
    twitter: 'https://twitter.com/rihanna',
    facebook: 'https://facebook.com/rihanna',
    image: 'https://upload.wikimedia.org/wikipedia/commons/c/c2/Rihanna_Fenty_2018.png',
    category: 'fashion',
    followers: 152000000,
    isVerified: true,
    netWorth: '$1.4 Billion',
    knownFor: 'Singer, Entrepreneur',
    location: 'Los Angeles, CA'
  },
  {
    name: 'Justin Bieber',
    username: 'justinbieber',
    bio: 'Singer and songwriter. Drew House founder. Justice World Tour.',
    instagram: 'https://instagram.com/justinbieber',
    twitter: 'https://twitter.com/justinbieber',
    facebook: 'https://facebook.com/JustinBieber',
    image: 'https://upload.wikimedia.org/wikipedia/commons/d/da/Justin_Bieber_in_2015.jpg',
    category: 'entertainment',
    followers: 293000000,
    isVerified: true,
    netWorth: '$300 Million',
    knownFor: 'Singer, Songwriter',
    location: 'Los Angeles, CA'
  },
  {
    name: 'Kendall Jenner',
    username: 'kendalljenner',
    bio: 'Model and entrepreneur. 818 Tequila founder. Kardashian-Jenner family member.',
    instagram: 'https://instagram.com/kendalljenner',
    twitter: 'https://twitter.com/KendallJenner',
    facebook: 'https://facebook.com/KendallJenner',
    image: 'https://upload.wikimedia.org/wikipedia/commons/7/7a/Kendall_Jenner_2019.jpg',
    category: 'fashion',
    followers: 294000000,
    isVerified: true,
    netWorth: '$60 Million',
    knownFor: 'Model, Entrepreneur',
    location: 'Los Angeles, CA'
  },
  {
    name: 'Jennifer Lopez',
    username: 'jlo',
    bio: 'Actress, singer, and dancer. JLO Beauty founder. Icon and legend.',
    instagram: 'https://instagram.com/jlo',
    twitter: 'https://twitter.com/JLo',
    facebook: 'https://facebook.com/jenniferlopez',
    image: 'https://upload.wikimedia.org/wikipedia/commons/6/68/Jennifer_Lopez_Interview_2019.jpg',
    category: 'entertainment',
    followers: 253000000,
    isVerified: true,
    netWorth: '$400 Million',
    knownFor: 'Actress, Singer, Dancer',
    location: 'Los Angeles, CA'
  },
  {
    name: 'Khloe Kardashian',
    username: 'khloekardashian',
    bio: 'TV personality and entrepreneur. Good American founder. Kardashian family member.',
    instagram: 'https://instagram.com/khloekardashian',
    twitter: 'https://twitter.com/khloekardashian',
    facebook: 'https://facebook.com/KhloeKardashian',
    image: 'https://upload.wikimedia.org/wikipedia/commons/0/0e/Khloe_Kardashian_2019.jpg',
    category: 'fashion',
    followers: 311000000,
    isVerified: true,
    netWorth: '$60 Million',
    knownFor: 'TV Personality, Entrepreneur',
    location: 'Los Angeles, CA'
  }
];

// Initialize celebrities in database
router.post('/init', async (req, res) => {
  try {
    await Celebrity.deleteMany({});
    
    for (const celeb of REAL_CELEBRITIES) {
      await Celebrity.create({
        ...celeb,
        isActive: true
      });
    }
    
    res.json({ message: `Initialized ${REAL_CELEBRITIES.length} celebrities` });
  } catch (error) {
    console.error('Init error:', error);
    res.status(500).json({ error: 'Failed to initialize celebrities' });
  }
});

// Get all celebrities
router.get('/', async (req, res) => {
  try {
    const { category, search } = req.query;
    let query: any = { isActive: true };
    
    if (category) query.category = category;
    if (search) {
      query.$or = [
        { name: { $regex: search, $options: 'i' } },
        { username: { $regex: search, $options: 'i' } }
      ];
    }
    
    const celebrities = await Celebrity.find(query)
      .sort({ followers: -1 })
      .limit(50);
    
    res.json(celebrities);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch celebrities' });
  }
});

// Get featured celebrities (for carousel)
router.get('/featured', async (req, res) => {
  try {
    const celebrities = await Celebrity.find({ isActive: true })
      .sort({ followers: -1 })
      .limit(10);
    res.json(celebrities);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch featured celebrities' });
  }
});

// Get single celebrity
router.get('/:username', async (req, res) => {
  try {
    const celebrity = await Celebrity.findOne({ username: req.params.username });
    if (!celebrity) {
      return res.status(404).json({ error: 'Celebrity not found' });
    }
    res.json(celebrity);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch celebrity' });
  }
});

// Get celebrity categories
router.get('/categories/all', async (req, res) => {
  try {
    const categories = [
      { id: 'all', name: 'All Celebrities' },
      { id: 'fashion', name: 'Fashion' },
      { id: 'entertainment', name: 'Entertainment' },
      { id: 'sports', name: 'Sports' },
      { id: 'business', name: 'Business' }
    ];
    res.json(categories);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch categories' });
  }
});

// Follow/unfollow celebrity
router.post('/:id/follow', auth, async (req, res) => {
  try {
    const celebrity = await Celebrity.findById(req.params.id);
    if (!celebrity) {
      return res.status(404).json({ error: 'Celebrity not found' });
    }
    
    // Add to user's following list
    res.json({ message: 'Followed celebrity', celebrity });
  } catch (error) {
    res.status(500).json({ error: 'Failed to follow celebrity' });
  }
});

export default router;
