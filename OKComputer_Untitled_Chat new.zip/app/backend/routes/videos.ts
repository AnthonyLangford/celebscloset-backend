import express from 'express';
import multer from 'multer';
import path from 'path';
import { fileURLToPath } from 'url';
import { auth, AuthRequest } from '../middleware/auth.js';
import { Video } from '../models/Video.js';
import { S3Client, PutObjectCommand, GetObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import { v4 as uuidv4 } from 'uuid';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const router = express.Router();

// Configure S3 client
const s3Client = new S3Client({
  region: process.env.AWS_REGION || 'us-east-1',
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID || '',
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY || ''
  }
});

const BUCKET_NAME = process.env.S3_BUCKET_NAME || 'celebscloset-videos';

// Local storage for development
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, '../uploads/videos'));
  },
  filename: (req, file, cb) => {
    const uniqueName = `${uuidv4()}${path.extname(file.originalname)}`;
    cb(null, uniqueName);
  }
});

const upload = multer({ 
  storage,
  limits: { fileSize: 100 * 1024 * 1024 }, // 100MB limit
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('video/')) {
      cb(null, true);
    } else {
      cb(new Error('Only video files are allowed'));
    }
  }
});

// Upload video
router.post('/upload', auth, upload.single('video'), async (req: AuthRequest, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No video file provided' });
    }

    const { title, description, isReel, isStory } = req.body;
    
    const video = new Video({
      userId: req.user._id,
      title: title || 'Untitled Video',
      description: description || '',
      videoUrl: `/uploads/videos/${req.file.filename}`,
      thumbnail: req.body.thumbnail || '',
      duration: req.body.duration || 0,
      isReel: isReel === 'true',
      isStory: isStory === 'true',
      views: 0,
      likes: [],
      comments: []
    });

    await video.save();
    await video.populate('userId', 'username fullName avatar isVerified');

    res.status(201).json(video);
  } catch (error) {
    console.error('Video upload error:', error);
    res.status(500).json({ error: 'Failed to upload video' });
  }
});

// Get all videos (reels)
router.get('/reels', async (req, res) => {
  try {
    const videos = await Video.find({ isReel: true })
      .populate('userId', 'username fullName avatar isVerified isCelebrity')
      .sort({ createdAt: -1 })
      .limit(50);
    res.json(videos);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch reels' });
  }
});

// Get stories
router.get('/stories', auth, async (req, res) => {
  try {
    const twentyFourHoursAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const stories = await Video.find({ 
      isStory: true, 
      createdAt: { $gte: twentyFourHoursAgo }
    })
      .populate('userId', 'username fullName avatar isVerified isCelebrity')
      .sort({ createdAt: -1 });
    res.json(stories);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch stories' });
  }
});

// Get single video
router.get('/:id', async (req, res) => {
  try {
    const video = await Video.findById(req.params.id)
      .populate('userId', 'username fullName avatar isVerified')
      .populate('comments.userId', 'username fullName avatar');
    
    if (!video) {
      return res.status(404).json({ error: 'Video not found' });
    }

    // Increment views
    video.views += 1;
    await video.save();

    res.json(video);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch video' });
  }
});

// Like video
router.post('/:id/like', auth, async (req: AuthRequest, res) => {
  try {
    const video = await Video.findById(req.params.id);
    if (!video) return res.status(404).json({ error: 'Video not found' });

    const likeIndex = video.likes.indexOf(req.user._id);
    if (likeIndex === -1) {
      video.likes.push(req.user._id);
    } else {
      video.likes.splice(likeIndex, 1);
    }
    
    await video.save();
    res.json(video);
  } catch (error) {
    res.status(500).json({ error: 'Failed to like video' });
  }
});

// Add comment
router.post('/:id/comment', auth, async (req: AuthRequest, res) => {
  try {
    const { content } = req.body;
    const video = await Video.findById(req.params.id);
    if (!video) return res.status(404).json({ error: 'Video not found' });

    video.comments.push({
      userId: req.user._id,
      content,
      createdAt: new Date()
    });
    
    await video.save();
    await video.populate('comments.userId', 'username fullName avatar');
    res.json(video);
  } catch (error) {
    res.status(500).json({ error: 'Failed to add comment' });
  }
});

// Share video
router.post('/:id/share', auth, async (req: AuthRequest, res) => {
  try {
    const { platform } = req.body; // 'facebook', 'twitter', 'instagram'
    const video = await Video.findById(req.params.id)
      .populate('userId', 'username fullName avatar');
    
    if (!video) return res.status(404).json({ error: 'Video not found' });

    video.shares = (video.shares || 0) + 1;
    await video.save();

    // Generate share URLs for different platforms
    const shareUrls: Record<string, string> = {
      facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(`${process.env.CLIENT_URL}/video/${video._id}`)}`,
      twitter: `https://twitter.com/intent/tweet?text=${encodeURIComponent(`Check out this video on CelebsCloset! ${video.title}`)}&url=${encodeURIComponent(`${process.env.CLIENT_URL}/video/${video._id}`)}`,
      instagram: `instagram://story-camera` // Instagram doesn't support direct URL sharing
    };

    res.json({ 
      video, 
      shareUrl: shareUrls[platform] || shareUrls.facebook,
      platform
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to share video' });
  }
});

// Stream video (for playback)
router.get('/stream/:id', async (req, res) => {
  try {
    const video = await Video.findById(req.params.id);
    if (!video) {
      return res.status(404).json({ error: 'Video not found' });
    }

    // For local files
    if (video.videoUrl.startsWith('/uploads')) {
      const videoPath = path.join(__dirname, '..', video.videoUrl);
      res.sendFile(videoPath);
    } else {
      // For S3 files, redirect to signed URL
      const command = new GetObjectCommand({
        Bucket: BUCKET_NAME,
        Key: video.s3Key
      });
      const signedUrl = await getSignedUrl(s3Client, command, { expiresIn: 3600 });
      res.redirect(signedUrl);
    }
  } catch (error) {
    res.status(500).json({ error: 'Failed to stream video' });
  }
});

export default router;
