import express from 'express';
import { Product } from '../models/Product';
import { Order } from '../models/Order';
import { User } from '../models/User';
import { auth, AuthRequest } from '../middleware/auth';

const router = express.Router();

// Get all products
router.get('/', async (req, res) => {
  try {
    const { category, search } = req.query;
    let query: any = { status: 'active' };
    
    if (category) query.category = category;
    if (search) {
      query.$or = [
        { title: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } }
      ];
    }
    
    const products = await Product.find(query)
      .populate('sellerId', 'username fullName avatar isVerified')
      .sort({ createdAt: -1 });
    res.json(products);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Get single product
router.get('/:id', async (req, res) => {
  try {
    const product = await Product.findById(req.params.id)
      .populate('sellerId', 'username fullName avatar isVerified')
      .populate('highestBidder', 'username fullName avatar');
    if (!product) return res.status(404).json({ error: 'Product not found' });
    res.json(product);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Create product
router.post('/', auth, async (req: AuthRequest, res) => {
  try {
    const { title, description, price, category, subcategory, images, condition, isAuction, auctionEndTime, startingBid } = req.body;
    
    const product = new Product({
      sellerId: req.user._id,
      title,
      description,
      price,
      category,
      subcategory,
      images,
      condition,
      isAuction,
      auctionEndTime,
      startingBid: startingBid || price,
      currentBid: startingBid || price
    });
    
    await product.save();
    await product.populate('sellerId', 'username fullName avatar isVerified');
    res.status(201).json(product);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Place bid
router.post('/:id/bid', auth, async (req: AuthRequest, res) => {
  try {
    const { amount } = req.body;
    const product = await Product.findById(req.params.id);
    
    if (!product) return res.status(404).json({ error: 'Product not found' });
    if (!product.isAuction) return res.status(400).json({ error: 'Not an auction' });
    if (product.status !== 'active') return res.status(400).json({ error: 'Auction ended' });
    if (product.auctionEndTime && new Date() > product.auctionEndTime) {
      return res.status(400).json({ error: 'Auction ended' });
    }
    if (amount <= product.currentBid) {
      return res.status(400).json({ error: 'Bid must be higher than current bid' });
    }
    if (product.sellerId.toString() === req.user._id) {
      return res.status(400).json({ error: 'Cannot bid on your own item' });
    }

    product.currentBid = amount;
    product.highestBidder = req.user._id;
    await product.save();
    
    await product.populate('highestBidder', 'username fullName avatar');
    res.json(product);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Buy now
router.post('/:id/buy', auth, async (req: AuthRequest, res) => {
  try {
    const product = await Product.findById(req.params.id);
    
    if (!product) return res.status(404).json({ error: 'Product not found' });
    if (product.status !== 'active') return res.status(400).json({ error: 'Item not available' });
    if (product.sellerId.toString() === req.user._id) {
      return res.status(400).json({ error: 'Cannot buy your own item' });
    }

    const platformFee = product.price * 0.10;
    const sellerEarnings = product.price - platformFee;

    const order = new Order({
      buyerId: req.user._id,
      sellerId: product.sellerId,
      productId: product._id,
      amount: product.price,
      platformFee,
      sellerEarnings,
      status: 'pending'
    });

    product.status = 'sold';
    product.buyerId = req.user._id;
    
    await order.save();
    await product.save();
    
    // Update seller balance
    await User.findByIdAndUpdate(product.sellerId, {
      $inc: { balance: sellerEarnings }
    });

    res.json({ order, product });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Get categories
router.get('/categories/all', async (req, res) => {
  try {
    const categories = [
      { id: 'fashion', name: 'Fashion', icon: 'Shirt' },
      { id: 'accessories', name: 'Accessories', icon: 'Watch' },
      { id: 'entertainment', name: 'Entertainment', icon: 'Film' },
      { id: 'real-estate', name: 'Real Estate', icon: 'Home' },
      { id: 'automotive', name: 'Automotive', icon: 'Car' }
    ];
    res.json(categories);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

export default router;
