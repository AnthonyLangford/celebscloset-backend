import React, { createContext, useContext, useState, useEffect } from 'react';
import type { User } from '@/types';

interface AuthContextType {
  user: User | null;
  token: string | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  ceoLogin: (masterKey: string) => Promise<void>;
  register: (data: RegisterData) => Promise<void>;
  logout: () => void;
  updateUser: (user: User) => void;
}

interface RegisterData {
  username: string;
  email: string;
  password: string;
  fullName: string;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Demo users for static deployment
const DEMO_USERS: Record<string, User> = {
  'ceo@celebscloset.com': {
    id: 'ceo-1',
    _id: 'ceo-1',
    username: 'anthonylangford',
    email: 'ceo@celebscloset.com',
    fullName: 'Anthony Langford',
    avatar: '/logo.jpg',
    bio: 'CEO & Co-Founder of CelebsCloset',
    isVerified: true,
    isCelebrity: true,
    isAdmin: true,
    isCEO: true,
    followers: [],
    following: [],
    socialLinks: {},
    balance: 100000
  }
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(localStorage.getItem('token'));
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const initAuth = () => {
      const storedUser = localStorage.getItem('user');
      const storedToken = localStorage.getItem('token');
      if (storedUser && storedToken) {
        setUser(JSON.parse(storedUser));
        setToken(storedToken);
      }
      setIsLoading(false);
    };

    initAuth();
  }, []);

  const login = async (email: string, _password: string) => {
    // Demo mode - accept any credentials
    const demoUser: User = {
      id: 'user-' + Date.now(),
      _id: 'user-' + Date.now(),
      username: email.split('@')[0],
      email: email,
      fullName: email.split('@')[0],
      avatar: '/logo.jpg',
      bio: '',
      isVerified: false,
      isCelebrity: false,
      isAdmin: false,
      isCEO: false,
      followers: [],
      following: [],
      socialLinks: {},
      balance: 0
    };

    const demoToken = 'demo-token-' + Date.now();
    localStorage.setItem('token', demoToken);
    localStorage.setItem('user', JSON.stringify(demoUser));
    setToken(demoToken);
    setUser(demoUser);
  };

  const ceoLogin = async (masterKey: string) => {
    if (masterKey !== 'anthony-langford-ceo-2024') {
      throw new Error('Invalid master key');
    }

    const ceo = DEMO_USERS['ceo@celebscloset.com'];
    const demoToken = 'ceo-token-' + Date.now();
    localStorage.setItem('token', demoToken);
    localStorage.setItem('user', JSON.stringify(ceo));
    setToken(demoToken);
    setUser(ceo);
  };

  const register = async (data: RegisterData) => {
    const newUser: User = {
      id: 'user-' + Date.now(),
      _id: 'user-' + Date.now(),
      username: data.username,
      email: data.email,
      fullName: data.fullName,
      avatar: '/logo.jpg',
      bio: '',
      isVerified: false,
      isCelebrity: false,
      isAdmin: false,
      isCEO: false,
      followers: [],
      following: [],
      socialLinks: {},
      balance: 0
    };

    const demoToken = 'demo-token-' + Date.now();
    localStorage.setItem('token', demoToken);
    localStorage.setItem('user', JSON.stringify(newUser));
    setToken(demoToken);
    setUser(newUser);
  };

  const logout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setToken(null);
    setUser(null);
  };

  const updateUser = (updatedUser: User) => {
    setUser(updatedUser);
    localStorage.setItem('user', JSON.stringify(updatedUser));
  };

  return (
    <AuthContext.Provider value={{ 
      user, 
      token, 
      isLoading, 
      login, 
      ceoLogin,
      register, 
      logout,
      updateUser
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
