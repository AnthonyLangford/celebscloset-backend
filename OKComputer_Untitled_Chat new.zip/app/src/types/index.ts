export interface User {
  id: string;
  _id: string;
  username: string;
  email: string;
  fullName: string;
  avatar: string;
  bio: string;
  isVerified: boolean;
  isCelebrity: boolean;
  isAdmin: boolean;
  isCEO: boolean;
  followers: string[];
  following: string[];
  socialLinks: {
    instagram?: string;
    facebook?: string;
    twitter?: string;
    youtube?: string;
  };
  balance: number;
}

export interface Post {
  _id: string;
  userId: User;
  content: string;
  media: string[];
  mediaType: 'image' | 'video';
  likes: string[];
  comments: Comment[];
  shares: number;
  isStory: boolean;
  storyExpiresAt?: string;
  createdAt: string;
}

export interface Comment {
  _id: string;
  userId: User;
  content: string;
  createdAt: string;
}

export interface Product {
  _id: string;
  sellerId: User;
  title: string;
  description: string;
  price: number;
  category: string;
  subcategory: string;
  images: string[];
  condition: 'new' | 'like-new' | 'good' | 'fair';
  isAuction: boolean;
  auctionEndTime?: string;
  currentBid: number;
  highestBidder?: User;
  startingBid: number;
  status: 'active' | 'sold' | 'ended';
  buyerId?: string;
  createdAt: string;
}

export interface Message {
  _id: string;
  senderId: User;
  receiverId: User;
  content: string;
  media?: string;
  mediaType?: 'image' | 'video';
  isRead: boolean;
  createdAt: string;
}

export interface Conversation {
  user: User;
  lastMessage: Message;
  unread: number;
}

export interface Reel {
  _id: string;
  userId: User;
  title: string;
  videoUrl: string;
  thumbnail: string;
  music?: string;
  likes: string[];
  comments: Comment[];
  shares: number;
  views: number;
  isLive: boolean;
  createdAt: string;
}

export interface Event {
  _id: string;
  celebrityId: User;
  title: string;
  description: string;
  venue: string;
  date: string;
  ticketPrice: number;
  totalTickets: number;
  soldTickets: number;
  image: string;
  status: 'upcoming' | 'ongoing' | 'completed';
}

export interface Order {
  _id: string;
  buyerId: string;
  sellerId: string;
  productId: string;
  amount: number;
  platformFee: number;
  sellerEarnings: number;
  status: 'pending' | 'paid' | 'shipped' | 'delivered' | 'cancelled';
  paymentIntentId?: string;
  createdAt: string;
}

export interface Category {
  id: string;
  name: string;
  icon: string;
}

export interface AIResponse {
  answer: string;
  suggestions: string[];
  action: string | null;
  data: any;
}
