import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, useNavigate } from 'react-router-dom';
import { AuthProvider, useAuth } from '@/context/AuthContext';
import { SocketProvider } from '@/context/SocketContext';
import { Layout } from '@/components/Layout';
import { Home } from '@/pages/Home';
import { Marketplace } from '@/pages/Marketplace';
import { Entertainment } from '@/pages/Entertainment';
import { Messages } from '@/pages/Messages';
import { Profile } from '@/pages/Profile';
import { Search } from '@/pages/Search';
import { Create } from '@/pages/Create';
import { Admin } from '@/pages/Admin';
import { Login } from '@/pages/Login';
import { Register } from '@/pages/Register';
import { Celebrities } from '@/pages/Celebrities';
import { NanaAI } from '@/components/NanaAI';
import { Toaster } from '@/components/ui/sonner';

const PrivateRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-yellow-500 border-t-transparent rounded-full" />
      </div>
    );
  }

  return user ? <>{children}</> : <Navigate to="/login" />;
};

const PublicRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-yellow-500 border-t-transparent rounded-full" />
      </div>
    );
  }

  return user ? <Navigate to="/" /> : <>{children}</>;
};

const AppWithNana: React.FC = () => {
  const navigate = useNavigate();
  const { user } = useAuth();

  return (
    <>
      <Routes>
        <Route
          path="/login"
          element={
            <PublicRoute>
              <Login />
            </PublicRoute>
          }
        />
        <Route
          path="/register"
          element={
            <PublicRoute>
              <Register />
            </PublicRoute>
          }
        />
        <Route
          path="/"
          element={
            <PrivateRoute>
              <Layout>
                <Home />
              </Layout>
            </PrivateRoute>
          }
        />
        <Route
          path="/marketplace"
          element={
            <PrivateRoute>
              <Layout>
                <Marketplace />
              </Layout>
            </PrivateRoute>
          }
        />
        <Route
          path="/entertainment"
          element={
            <PrivateRoute>
              <Layout>
                <Entertainment />
              </Layout>
            </PrivateRoute>
          }
        />
        <Route
          path="/messages"
          element={
            <PrivateRoute>
              <Layout>
                <Messages />
              </Layout>
            </PrivateRoute>
          }
        />
        <Route
          path="/profile"
          element={
            <PrivateRoute>
              <Layout>
                <Profile />
              </Layout>
            </PrivateRoute>
          }
        />
        <Route
          path="/profile/:username"
          element={
            <PrivateRoute>
              <Layout>
                <Profile />
              </Layout>
            </PrivateRoute>
          }
        />
        <Route
          path="/search"
          element={
            <PrivateRoute>
              <Layout>
                <Search />
              </Layout>
            </PrivateRoute>
          }
        />
        <Route
          path="/create"
          element={
            <PrivateRoute>
              <Layout>
                <Create />
              </Layout>
            </PrivateRoute>
          }
        />
        <Route
          path="/admin"
          element={
            <PrivateRoute>
              <Layout>
                <Admin />
              </Layout>
            </PrivateRoute>
          }
        />
        <Route
          path="/celebrities"
          element={
            <PrivateRoute>
              <Layout>
                <Celebrities />
              </Layout>
            </PrivateRoute>
          }
        />
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
      
      {/* Nana AI Assistant - Available everywhere when logged in */}
      {user && <NanaAI onNavigate={navigate} />}
    </>
  );
};

function App() {
  return (
    <AuthProvider>
      <SocketProvider>
        <Router>
          <AppWithNana />
        </Router>
        <Toaster />
      </SocketProvider>
    </AuthProvider>
  );
}

export default App;
