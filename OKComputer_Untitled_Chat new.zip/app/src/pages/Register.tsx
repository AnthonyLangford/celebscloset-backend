import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Eye, EyeOff, User, Mail, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useAuth } from '@/context/AuthContext';

export const Register: React.FC = () => {
  const navigate = useNavigate();
  const { register } = useAuth();
  const [formData, setFormData] = useState({
    fullName: '',
    username: '',
    email: '',
    password: '',
    confirmPassword: ''
  });
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match');
      return;
    }

    if (formData.password.length < 6) {
      setError('Password must be at least 6 characters');
      return;
    }

    setLoading(true);
    try {
      await register({
        fullName: formData.fullName,
        username: formData.username,
        email: formData.email,
        password: formData.password
      });
      navigate('/');
    } catch (error: any) {
      setError(error.message || 'Registration failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-black flex items-center justify-center p-4 relative overflow-hidden">
      {/* Gold gradient background effect */}
      <div className="absolute inset-0 bg-gradient-to-br from-yellow-900/20 via-black to-yellow-800/20" />
      <div className="absolute top-0 left-0 w-full h-full">
        <div className="absolute top-10 right-10 w-32 h-32 bg-yellow-500/10 rounded-full blur-3xl" />
        <div className="absolute bottom-10 left-10 w-48 h-48 bg-yellow-600/10 rounded-full blur-3xl" />
      </div>

      <div className="w-full max-w-md relative z-10">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="w-24 h-24 mx-auto rounded-2xl overflow-hidden border-2 border-yellow-500/50 shadow-[0_0_30px_rgba(234,179,8,0.3)] mb-4">
            <img src="/logo.jpg" alt="CelebsCloset" className="w-full h-full object-cover" />
          </div>
          <h1 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 via-yellow-500 to-yellow-300">
            Join CelebsCloset
          </h1>
          <p className="text-yellow-500/70 mt-2 text-sm tracking-widest uppercase">Start Your Luxury Journey</p>
        </div>

        {/* Register Form */}
        <div className="bg-gradient-to-b from-yellow-950/30 to-black/50 backdrop-blur-xl rounded-2xl border border-yellow-500/30 p-8 shadow-[0_0_40px_rgba(234,179,8,0.1)]">
          {error && (
            <div className="mb-4 p-3 bg-red-500/20 border border-red-500/30 rounded-lg text-red-400 text-sm text-center">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm text-yellow-500/70 mb-1 uppercase tracking-wider text-xs">Full Name</label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-yellow-500/50" />
                <Input
                  type="text"
                  value={formData.fullName}
                  onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                  placeholder="Enter your full name"
                  className="pl-10 bg-black/50 border-yellow-500/30 text-yellow-100 placeholder:text-yellow-500/30 focus:border-yellow-400 focus:ring-yellow-400/20"
                  required
                />
              </div>
            </div>
            <div>
              <label className="block text-sm text-yellow-500/70 mb-1 uppercase tracking-wider text-xs">Username</label>
              <Input
                type="text"
                value={formData.username}
                onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                placeholder="Choose a username"
                className="bg-black/50 border-yellow-500/30 text-yellow-100 placeholder:text-yellow-500/30 focus:border-yellow-400 focus:ring-yellow-400/20"
                required
              />
            </div>
            <div>
              <label className="block text-sm text-yellow-500/70 mb-1 uppercase tracking-wider text-xs">Email</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-yellow-500/50" />
                <Input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="Enter your email"
                  className="pl-10 bg-black/50 border-yellow-500/30 text-yellow-100 placeholder:text-yellow-500/30 focus:border-yellow-400 focus:ring-yellow-400/20"
                  required
                />
              </div>
            </div>
            <div>
              <label className="block text-sm text-yellow-500/70 mb-1 uppercase tracking-wider text-xs">Password</label>
              <div className="relative">
                <Input
                  type={showPassword ? 'text' : 'password'}
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  placeholder="Create a password"
                  className="bg-black/50 border-yellow-500/30 text-yellow-100 placeholder:text-yellow-500/30 focus:border-yellow-400 focus:ring-yellow-400/20 pr-10"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-yellow-500/50 hover:text-yellow-400"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
            <div>
              <label className="block text-sm text-yellow-500/70 mb-1 uppercase tracking-wider text-xs">Confirm Password</label>
              <Input
                type="password"
                value={formData.confirmPassword}
                onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                placeholder="Confirm your password"
                className="bg-black/50 border-yellow-500/30 text-yellow-100 placeholder:text-yellow-500/30 focus:border-yellow-400 focus:ring-yellow-400/20"
                required
              />
            </div>
            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-yellow-600 via-yellow-500 to-yellow-600 hover:from-yellow-500 hover:via-yellow-400 hover:to-yellow-500 text-black font-bold py-6 shadow-[0_0_20px_rgba(234,179,8,0.4)] hover:shadow-[0_0_30px_rgba(234,179,8,0.6)] transition-all"
              disabled={loading}
            >
              {loading ? 'Creating account...' : 'Create Account'}
            </Button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-yellow-500/50">
              Already have an account?{' '}
              <Link to="/login" className="text-yellow-400 hover:text-yellow-300 font-medium">
                Sign in
              </Link>
            </p>
          </div>
        </div>

        {/* Decorative elements */}
        <div className="flex justify-center gap-2 mt-6">
          <Sparkles className="w-4 h-4 text-yellow-500/30" />
          <span className="text-yellow-500/30 text-xs">Social Commerce 2.0</span>
          <Sparkles className="w-4 h-4 text-yellow-500/30" />
        </div>
      </div>
    </div>
  );
};
