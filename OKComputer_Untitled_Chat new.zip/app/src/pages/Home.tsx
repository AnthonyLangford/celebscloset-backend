import React, { useState, useRef } from 'react';
import { Heart, MessageCircle, Share2, Bookmark, MoreHorizontal, Send, Crown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { useAuth } from '@/context/AuthContext';
import type { Post, User } from '@/types';

// Demo data
const DEMO_POSTS: Post[] = [
  {
    _id: '1',
    userId: {
      id: 'user1',
      _id: 'user1',
      username: 'luxuryfashion',
      email: 'fashion@example.com',
      fullName: 'Luxury Fashion',
      avatar: '/logo.jpg',
      bio: 'Premium fashion curator',
      isVerified: true,
      isCelebrity: true,
      isAdmin: false,
      isCEO: false,
      followers: [],
      following: [],
      socialLinks: {},
      balance: 0
    },
    content: 'Check out this amazing designer collection! Available now on CelebsCloset. #Luxury #Fashion',
    media: ['https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=600'],
    mediaType: 'image',
    likes: [],
    comments: [],
    shares: 45,
    isStory: false,
    createdAt: new Date().toISOString()
  },
  {
    _id: '2',
    userId: {
      id: 'user2',
      _id: 'user2',
      username: 'celebritystyle',
      email: 'style@example.com',
      fullName: 'Celebrity Style',
      avatar: '/logo.jpg',
      bio: 'Celebrity fashion expert',
      isVerified: true,
      isCelebrity: true,
      isAdmin: false,
      isCEO: false,
      followers: [],
      following: [],
      socialLinks: {},
      balance: 0
    },
    content: 'New arrivals in the marketplace! Don\'t miss out on these exclusive pieces.',
    media: ['https://images.unsplash.com/photo-1445205170230-053b83016050?w=600'],
    mediaType: 'image',
    likes: ['user1'],
    comments: [],
    shares: 23,
    isStory: false,
    createdAt: new Date().toISOString()
  }
];

const DEMO_CELEBRITIES: User[] = [
  {
    id: 'cel1',
    _id: 'cel1',
    username: 'styleicon',
    email: 'icon@example.com',
    fullName: 'Style Icon',
    avatar: '/logo.jpg',
    bio: 'Fashion influencer & trendsetter',
    isVerified: true,
    isCelebrity: true,
    isAdmin: false,
    isCEO: false,
    followers: [],
    following: [],
    socialLinks: { instagram: '#', facebook: '#' },
    balance: 0
  },
  {
    id: 'cel2',
    _id: 'cel2',
    username: 'luxurydealer',
    email: 'dealer@example.com',
    fullName: 'Luxury Dealer',
    avatar: '/logo.jpg',
    bio: 'Premium goods specialist',
    isVerified: true,
    isCelebrity: true,
    isAdmin: false,
    isCEO: false,
    followers: [],
    following: [],
    socialLinks: { instagram: '#' },
    balance: 0
  }
];

const DEMO_STORIES: Post[] = [
  {
    _id: 'story1',
    userId: DEMO_CELEBRITIES[0],
    content: 'New story!',
    media: ['https://images.unsplash.com/photo-1469334031218-e382a71b716b?w=200'],
    mediaType: 'image',
    likes: [],
    comments: [],
    shares: 0,
    isStory: true,
    storyExpiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
    createdAt: new Date().toISOString()
  }
];

export const Home: React.FC = () => {
  const { user } = useAuth();
  const [posts, setPosts] = useState<Post[]>(DEMO_POSTS);
  const [stories] = useState<Post[]>(DEMO_STORIES);
  const [celebrities] = useState<User[]>(DEMO_CELEBRITIES);
  const [commentText, setCommentText] = useState('');
  const [activePost, setActivePost] = useState<Post | null>(null);
  const [showComments, setShowComments] = useState(false);
  const storiesRef = useRef<HTMLDivElement>(null);
  const celebsRef = useRef<HTMLDivElement>(null);

  const handleLike = (postId: string) => {
    setPosts(posts.map(p => {
      if (p._id === postId) {
        const isLiked = p.likes.includes(user?.id || '');
        return {
          ...p,
          likes: isLiked ? p.likes.filter(id => id !== user?.id) : [...p.likes, user?.id || '']
        };
      }
      return p;
    }));
  };

  const handleShare = async (post: Post) => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'CelebsCloset',
          text: post.content,
          url: window.location.href
        });
      } catch (error) {
        console.error('Error sharing:', error);
      }
    }
  };

  const scrollStories = (direction: 'left' | 'right') => {
    if (storiesRef.current) {
      storiesRef.current.scrollBy({ left: direction === 'left' ? -200 : 200, behavior: 'smooth' });
    }
  };

  const scrollCelebs = (direction: 'left' | 'right') => {
    if (celebsRef.current) {
      celebsRef.current.scrollBy({ left: direction === 'left' ? -300 : 300, behavior: 'smooth' });
    }
  };

  return (
    <div className="space-y-6">
      {/* Stories Wheel */}
      <div className="relative">
        <h2 className="text-lg font-semibold mb-3 flex items-center gap-2 text-yellow-400">
          <span className="w-2 h-2 bg-yellow-500 rounded-full animate-pulse" />
          Stories
        </h2>
        <div className="relative">
          <button
            onClick={() => scrollStories('left')}
            className="absolute left-0 top-1/2 -translate-y-1/2 z-10 w-8 h-8 bg-black/80 border border-yellow-500/30 rounded-full flex items-center justify-center text-yellow-400 hover:bg-yellow-500/20"
          >
            ←
          </button>
          <div
            ref={storiesRef}
            className="flex gap-4 overflow-x-auto scrollbar-hide py-2 px-8"
            style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
          >
            {/* Add Story Button */}
            <div className="flex-shrink-0 flex flex-col items-center gap-1">
              <div className="w-16 h-16 rounded-full border-2 border-dashed border-yellow-500/50 flex items-center justify-center cursor-pointer hover:bg-yellow-500/10 transition-colors">
                <span className="text-2xl text-yellow-500">+</span>
              </div>
              <span className="text-xs text-yellow-500/60">Add Story</span>
            </div>
            
            {/* Story Items */}
            {stories.map((story) => (
              <div key={story._id} className="flex-shrink-0 flex flex-col items-center gap-1 cursor-pointer">
                <div className="w-16 h-16 rounded-full p-0.5 bg-gradient-to-br from-yellow-400 via-yellow-500 to-yellow-600">
                  <Avatar className="w-full h-full border-2 border-black">
                    <AvatarImage src={story.userId.avatar} />
                    <AvatarFallback className="bg-yellow-950 text-yellow-400">{story.userId.username[0]}</AvatarFallback>
                  </Avatar>
                </div>
                <span className="text-xs text-yellow-500/60 truncate max-w-[64px]">
                  {story.userId.username}
                </span>
              </div>
            ))}
          </div>
          <button
            onClick={() => scrollStories('right')}
            className="absolute right-0 top-1/2 -translate-y-1/2 z-10 w-8 h-8 bg-black/80 border border-yellow-500/30 rounded-full flex items-center justify-center text-yellow-400 hover:bg-yellow-500/20"
          >
            →
          </button>
        </div>
      </div>

      {/* Celebrity Spotlight Carousel */}
      <div className="relative">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-semibold flex items-center gap-2 text-yellow-400">
            <Crown className="w-5 h-5" />
            Celebrity Spotlight
          </h2>
          <button className="text-sm text-yellow-500/70 hover:text-yellow-400">See More</button>
        </div>
        <div className="relative">
          <button
            onClick={() => scrollCelebs('left')}
            className="absolute left-0 top-1/2 -translate-y-1/2 z-10 w-8 h-8 bg-black/80 border border-yellow-500/30 rounded-full flex items-center justify-center text-yellow-400 hover:bg-yellow-500/20"
          >
            ←
          </button>
          <div
            ref={celebsRef}
            className="flex gap-4 overflow-x-auto scrollbar-hide py-2 px-8"
            style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
          >
            {celebrities.map((celebrity) => (
              <div
                key={celebrity.id}
                className="flex-shrink-0 w-64 bg-gradient-to-b from-yellow-950/30 to-black rounded-xl overflow-hidden border border-yellow-500/20 hover:border-yellow-500/40 transition-all"
              >
                <div className="h-24 bg-gradient-to-br from-yellow-600/30 to-yellow-800/30 relative">
                  <div className="absolute -bottom-8 left-4">
                    <Avatar className="w-16 h-16 border-4 border-black">
                      <AvatarImage src={celebrity.avatar} />
                      <AvatarFallback className="bg-yellow-950 text-yellow-400">{celebrity.username[0]}</AvatarFallback>
                    </Avatar>
                  </div>
                </div>
                <div className="pt-10 pb-4 px-4">
                  <div className="flex items-center gap-1">
                    <h3 className="font-semibold text-yellow-100">{celebrity.fullName}</h3>
                    {celebrity.isVerified && (
                      <span className="text-yellow-400 text-xs"><Crown className="w-3 h-3" /></span>
                    )}
                  </div>
                  <p className="text-sm text-yellow-500/60">@{celebrity.username}</p>
                  <p className="text-xs text-yellow-500/40 mt-1 line-clamp-2">{celebrity.bio}</p>
                  <div className="flex gap-2 mt-3">
                    {celebrity.socialLinks?.instagram && (
                      <a
                        href={celebrity.socialLinks.instagram}
                        className="text-xs bg-gradient-to-r from-yellow-600 to-yellow-500 text-black px-2 py-1 rounded-full font-medium"
                      >
                        Instagram
                      </a>
                    )}
                    {celebrity.socialLinks?.facebook && (
                      <a
                        href={celebrity.socialLinks.facebook}
                        className="text-xs bg-yellow-500/20 text-yellow-400 border border-yellow-500/30 px-2 py-1 rounded-full"
                      >
                        Facebook
                      </a>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
          <button
            onClick={() => scrollCelebs('right')}
            className="absolute right-0 top-1/2 -translate-y-1/2 z-10 w-8 h-8 bg-black/80 border border-yellow-500/30 rounded-full flex items-center justify-center text-yellow-400 hover:bg-yellow-500/20"
          >
            →
          </button>
        </div>
      </div>

      {/* Feed Posts */}
      <div className="space-y-6">
        {posts.map((post) => (
          <div key={post._id} className="bg-gradient-to-b from-yellow-950/20 to-black rounded-xl border border-yellow-500/20 overflow-hidden">
            {/* Post Header */}
            <div className="flex items-center justify-between p-4">
              <div className="flex items-center gap-3">
                <Avatar className="border border-yellow-500/30">
                  <AvatarImage src={post.userId.avatar} />
                  <AvatarFallback className="bg-yellow-950 text-yellow-400">{post.userId.username[0]}</AvatarFallback>
                </Avatar>
                <div>
                  <div className="flex items-center gap-1">
                    <span className="font-semibold text-yellow-100">{post.userId.username}</span>
                    {post.userId.isVerified && <Crown className="w-3 h-3 text-yellow-400" />}
                  </div>
                  <span className="text-xs text-yellow-500/50">
                    {new Date(post.createdAt).toLocaleDateString()}
                  </span>
                </div>
              </div>
              <Button variant="ghost" size="icon" className="text-yellow-500/50 hover:text-yellow-400">
                <MoreHorizontal className="w-5 h-5" />
              </Button>
            </div>

            {/* Post Content */}
            {post.media?.length > 0 && (
              <div className="aspect-square bg-black">
                <img
                  src={post.media[0]}
                  alt="Post"
                  className="w-full h-full object-cover"
                />
              </div>
            )}

            {/* Post Actions */}
            <div className="p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-4">
                  <Button
                    variant="ghost"
                    size="icon"
                    className={`${post.likes.includes(user?.id || '') ? 'text-red-500' : 'text-yellow-500/60 hover:text-yellow-400'}`}
                    onClick={() => handleLike(post._id)}
                  >
                    <Heart className={`w-6 h-6 ${post.likes.includes(user?.id || '') ? 'fill-current' : ''}`} />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="text-yellow-500/60 hover:text-yellow-400"
                    onClick={() => {
                      setActivePost(post);
                      setShowComments(true);
                    }}
                  >
                    <MessageCircle className="w-6 h-6" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="text-yellow-500/60 hover:text-yellow-400"
                    onClick={() => handleShare(post)}
                  >
                    <Share2 className="w-6 h-6" />
                  </Button>
                </div>
                <Button variant="ghost" size="icon" className="text-yellow-500/60 hover:text-yellow-400">
                  <Bookmark className="w-6 h-6" />
                </Button>
              </div>

              {/* Likes Count */}
              <p className="font-semibold mb-1 text-yellow-100">{post.likes.length} likes</p>

              {/* Caption */}
              <p className="text-yellow-200/70 mb-2">
                <span className="font-semibold text-yellow-100 mr-2">{post.userId.username}</span>
                {post.content}
              </p>

              {/* Comments Preview */}
              {post.comments.length > 0 && (
                <button
                  className="text-yellow-500/50 text-sm mb-2"
                  onClick={() => {
                    setActivePost(post);
                    setShowComments(true);
                  }}
                >
                  View all {post.comments.length} comments
                </button>
              )}

              {/* Add Comment */}
              <div className="flex items-center gap-2 mt-2">
                <Input
                  placeholder="Add a comment..."
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  className="flex-1 bg-transparent border-none text-yellow-100 placeholder:text-yellow-500/30"
                />
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-yellow-500 hover:text-yellow-400"
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Comments Dialog */}
      <Dialog open={showComments} onOpenChange={setShowComments}>
        <DialogContent className="bg-black border-yellow-500/30 text-yellow-100 max-w-lg max-h-[80vh] overflow-hidden">
          <div className="flex flex-col h-full">
            <h3 className="font-semibold mb-4 text-yellow-400">Comments</h3>
            <div className="flex-1 overflow-y-auto space-y-4">
              {activePost?.comments.map((comment) => (
                <div key={comment._id} className="flex gap-3">
                  <Avatar className="w-8 h-8 border border-yellow-500/30">
                    <AvatarImage src={comment.userId.avatar} />
                    <AvatarFallback className="bg-yellow-950 text-yellow-400 text-xs">{comment.userId.username[0]}</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-sm text-yellow-100">{comment.userId.username}</span>
                      <span className="text-xs text-yellow-500/40">
                        {new Date(comment.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                    <p className="text-yellow-200/70 text-sm">{comment.content}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};
