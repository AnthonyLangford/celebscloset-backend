import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { Grid, Bookmark, Settings, Edit, Crown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useAuth } from '@/context/AuthContext';
import type { User } from '@/types';

const DEMO_POSTS = [
  'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=300',
  'https://images.unsplash.com/photo-1529139574466-a303027c1d8b?w=300',
  'https://images.unsplash.com/photo-1496747611176-843222e1e57c?w=300',
];

export const Profile: React.FC = () => {
  const { username } = useParams();
  const { user: currentUser, updateUser } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState<Partial<User>>(currentUser || {});

  const isOwnProfile = !username || username === currentUser?.username;
  const profile = currentUser;

  const handleSaveProfile = () => {
    if (profile) {
      const updated = { ...profile, ...editData };
      updateUser(updated);
      setIsEditing(false);
    }
  };

  if (!profile) {
    return (
      <div className="text-center py-12 text-yellow-500/50">
        <p>User not found</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Profile Header */}
      <div className="bg-gradient-to-b from-yellow-950/30 to-black rounded-xl border border-yellow-500/20 p-6">
        <div className="flex flex-col md:flex-row gap-6">
          {/* Avatar */}
          <div className="flex justify-center md:justify-start">
            <Avatar className="w-24 h-24 md:w-32 md:h-32 border-4 border-yellow-500/30">
              <AvatarImage src={profile.avatar} />
              <AvatarFallback className="bg-yellow-950 text-yellow-400 text-2xl">{profile.username[0]}</AvatarFallback>
            </Avatar>
          </div>

          {/* Info */}
          <div className="flex-1 text-center md:text-left">
            <div className="flex flex-col md:flex-row items-center gap-4 mb-4">
              <h1 className="text-2xl font-bold text-yellow-100">{profile.username}</h1>
              {profile.isVerified && (
                <span className="bg-yellow-500/20 text-yellow-400 text-xs px-2 py-1 rounded-full flex items-center gap-1 border border-yellow-500/30">
                  <Crown className="w-3 h-3" />
                  Verified
                </span>
              )}
              {profile.isCelebrity && (
                <span className="bg-gradient-to-r from-yellow-600 to-yellow-500 text-black text-xs px-2 py-1 rounded-full font-bold">
                  Celebrity
                </span>
              )}
            </div>

            {isEditing ? (
              <div className="space-y-3">
                <input
                  type="text"
                  value={editData.fullName}
                  onChange={(e) => setEditData({ ...editData, fullName: e.target.value })}
                  className="w-full p-2 bg-yellow-950/50 border border-yellow-500/30 rounded text-yellow-100 placeholder:text-yellow-500/40"
                  placeholder="Full Name"
                />
                <textarea
                  value={editData.bio}
                  onChange={(e) => setEditData({ ...editData, bio: e.target.value })}
                  className="w-full p-2 bg-yellow-950/50 border border-yellow-500/30 rounded text-yellow-100 placeholder:text-yellow-500/40 resize-none"
                  rows={2}
                  placeholder="Bio"
                />
                <div className="flex gap-2">
                  <Button 
                    onClick={handleSaveProfile} 
                    className="bg-gradient-to-r from-yellow-600 to-yellow-500 text-black font-bold hover:from-yellow-500 hover:to-yellow-400"
                  >
                    Save
                  </Button>
                  <Button variant="outline" onClick={() => setIsEditing(false)} className="border-yellow-500/30 text-yellow-400">
                    Cancel
                  </Button>
                </div>
              </div>
            ) : (
              <>
                <p className="text-yellow-200/70 mb-2">{profile.fullName}</p>
                <p className="text-yellow-500/60 mb-4">{profile.bio || 'No bio yet'}</p>

                {/* Stats */}
                <div className="flex justify-center md:justify-start gap-6 mb-4">
                  <div className="text-center">
                    <p className="font-bold text-xl text-yellow-100">{DEMO_POSTS.length}</p>
                    <p className="text-sm text-yellow-500/60">Posts</p>
                  </div>
                  <div className="text-center">
                    <p className="font-bold text-xl text-yellow-100">{profile.followers.length}</p>
                    <p className="text-sm text-yellow-500/60">Followers</p>
                  </div>
                  <div className="text-center">
                    <p className="font-bold text-xl text-yellow-100">{profile.following.length}</p>
                    <p className="text-sm text-yellow-500/60">Following</p>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex justify-center md:justify-start gap-2">
                  {isOwnProfile ? (
                    <>
                      <Button
                        variant="outline"
                        className="border-yellow-500/30 text-yellow-400 hover:bg-yellow-500/10"
                        onClick={() => setIsEditing(true)}
                      >
                        <Edit className="w-4 h-4 mr-2" />
                        Edit Profile
                      </Button>
                      <Button variant="outline" className="border-yellow-500/30 text-yellow-400 hover:bg-yellow-500/10">
                        <Settings className="w-4 h-4 mr-2" />
                        Settings
                      </Button>
                    </>
                  ) : (
                    <Button className="bg-gradient-to-r from-yellow-600 to-yellow-500 text-black font-bold hover:from-yellow-500 hover:to-yellow-400">
                      Follow
                    </Button>
                  )}
                </div>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="posts">
        <TabsList className="bg-yellow-950/30 border border-yellow-500/20 w-full justify-start">
          <TabsTrigger value="posts" className="flex-1 data-[state=active]:bg-yellow-500 data-[state=active]:text-black">
            <Grid className="w-4 h-4 mr-2" />
            Posts
          </TabsTrigger>
          <TabsTrigger value="shop" className="flex-1 data-[state=active]:bg-yellow-500 data-[state=active]:text-black">
            <Bookmark className="w-4 h-4 mr-2" />
            Shop
          </TabsTrigger>
          {isOwnProfile && (
            <TabsTrigger value="saved" className="flex-1 data-[state=active]:bg-yellow-500 data-[state=active]:text-black">
              <Bookmark className="w-4 h-4 mr-2" />
              Saved
            </TabsTrigger>
          )}
        </TabsList>

        <TabsContent value="posts" className="mt-4">
          <div className="grid grid-cols-3 gap-1 md:gap-4">
            {DEMO_POSTS.map((post, idx) => (
              <div
                key={idx}
                className="aspect-square bg-yellow-950/30 rounded-lg overflow-hidden cursor-pointer hover:opacity-80 transition-opacity border border-yellow-500/20"
              >
                <img src={post} alt="Post" className="w-full h-full object-cover" />
              </div>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="shop" className="mt-4">
          <div className="text-center py-12 text-yellow-500/50">
            <Bookmark className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>No items for sale</p>
          </div>
        </TabsContent>

        {isOwnProfile && (
          <TabsContent value="saved" className="mt-4">
            <div className="text-center py-12 text-yellow-500/50">
              <Bookmark className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>No saved posts</p>
            </div>
          </TabsContent>
        )}
      </Tabs>
    </div>
  );
};
