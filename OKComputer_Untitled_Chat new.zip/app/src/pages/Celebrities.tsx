import React, { useEffect, useState, useRef } from 'react';
import { Crown, Instagram, Twitter, Facebook, ChevronLeft, ChevronRight, Users, DollarSign, MapPin } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

interface Celebrity {
  _id: string;
  name: string;
  username: string;
  bio: string;
  image: string;
  instagram: string;
  twitter: string;
  facebook: string;
  category: string;
  followers: number;
  isVerified: boolean;
  netWorth?: string;
  knownFor?: string;
  location?: string;
}

export const Celebrities: React.FC = () => {
  const [celebrities, setCelebrities] = useState<Celebrity[]>([]);
  const [featuredCelebs, setFeaturedCelebs] = useState<Celebrity[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const carouselRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    fetchCelebrities();
    fetchFeaturedCelebrities();
  }, []);

  const fetchCelebrities = async () => {
    try {
      const res = await fetch('/api/celebrities', {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      });
      const data = await res.json();
      setCelebrities(data);
    } catch (error) {
      console.error('Error fetching celebrities:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchFeaturedCelebrities = async () => {
    try {
      const res = await fetch('/api/celebrities/featured', {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      });
      const data = await res.json();
      setFeaturedCelebs(data);
    } catch (error) {
      console.error('Error fetching featured celebrities:', error);
    }
  };

  const scrollCarousel = (direction: 'left' | 'right') => {
    if (carouselRef.current) {
      carouselRef.current.scrollBy({ left: direction === 'left' ? -400 : 400, behavior: 'smooth' });
    }
  };

  const formatFollowers = (count: number) => {
    if (count >= 1000000) return `${(count / 1000000).toFixed(0)}M`;
    if (count >= 1000) return `${(count / 1000).toFixed(0)}K`;
    return count.toString();
  };

  const filteredCelebrities = celebrities.filter(c => 
    c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.username.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin w-8 h-8 border-4 border-yellow-500 border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 to-yellow-500">
          Celebrity Spotlight
        </h1>
        <p className="text-yellow-500/60">Connect with your favorite stars on CelebsCloset</p>
      </div>

      {/* Featured Carousel */}
      <div className="relative">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold text-yellow-100 flex items-center gap-2">
            <Crown className="w-5 h-5 text-yellow-500" />
            Featured Celebrities
          </h2>
          <div className="flex gap-2">
            <button
              onClick={() => scrollCarousel('left')}
              className="w-8 h-8 bg-yellow-950/50 border border-yellow-500/30 rounded-full flex items-center justify-center text-yellow-400 hover:bg-yellow-500/20"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={() => scrollCarousel('right')}
              className="w-8 h-8 bg-yellow-950/50 border border-yellow-500/30 rounded-full flex items-center justify-center text-yellow-400 hover:bg-yellow-500/20"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div
          ref={carouselRef}
          className="flex gap-4 overflow-x-auto scrollbar-hide pb-4"
          style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
        >
          {featuredCelebs.map((celeb) => (
            <div
              key={celeb._id}
              className="flex-shrink-0 w-80 bg-gradient-to-b from-yellow-950/30 to-black rounded-2xl border border-yellow-500/20 overflow-hidden hover:border-yellow-500/40 transition-all group"
            >
              {/* Cover Image */}
              <div className="h-40 relative overflow-hidden">
                <img
                  src={celeb.image}
                  alt={celeb.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent" />
                <div className="absolute bottom-3 left-3 right-3">
                  <div className="flex items-center gap-2">
                    <img
                      src={celeb.image}
                      alt={celeb.name}
                      className="w-14 h-14 rounded-full border-2 border-yellow-500 object-cover"
                    />
                    <div>
                      <h3 className="font-bold text-yellow-100">{celeb.name}</h3>
                      <p className="text-sm text-yellow-500/60">@{celeb.username}</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Info */}
              <div className="p-4 space-y-3">
                <p className="text-sm text-yellow-200/70 line-clamp-2">{celeb.bio}</p>
                
                <div className="flex flex-wrap gap-2">
                  {celeb.knownFor && (
                    <Badge className="bg-yellow-500/20 text-yellow-400 border border-yellow-500/30">
                      {celeb.knownFor}
                    </Badge>
                  )}
                  {celeb.netWorth && (
                    <Badge className="bg-green-500/20 text-green-400 border border-green-500/30 flex items-center gap-1">
                      <DollarSign className="w-3 h-3" />
                      {celeb.netWorth}
                    </Badge>
                  )}
                </div>

                <div className="flex items-center gap-4 text-sm text-yellow-500/60">
                  <span className="flex items-center gap-1">
                    <Users className="w-4 h-4" />
                    {formatFollowers(celeb.followers)}
                  </span>
                  {celeb.location && (
                    <span className="flex items-center gap-1">
                      <MapPin className="w-4 h-4" />
                      {celeb.location}
                    </span>
                  )}
                </div>

                {/* Social Links */}
                <div className="flex gap-2">
                  {celeb.instagram && (
                    <a
                      href={celeb.instagram}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 flex items-center justify-center gap-2 py-2 bg-gradient-to-r from-purple-600 to-pink-500 rounded-lg text-white text-sm font-medium hover:opacity-90"
                    >
                      <Instagram className="w-4 h-4" />
                      Instagram
                    </a>
                  )}
                  {celeb.twitter && (
                    <a
                      href={celeb.twitter}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-10 h-10 flex items-center justify-center bg-blue-500 rounded-lg text-white hover:opacity-90"
                    >
                      <Twitter className="w-4 h-4" />
                    </a>
                  )}
                  {celeb.facebook && (
                    <a
                      href={celeb.facebook}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-10 h-10 flex items-center justify-center bg-blue-700 rounded-lg text-white hover:opacity-90"
                    >
                      <Facebook className="w-4 h-4" />
                    </a>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Search and Filter */}
      <div className="space-y-4">
        <Input
          placeholder="Search celebrities..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="bg-yellow-950/30 border-yellow-500/30 text-yellow-100 placeholder:text-yellow-500/40"
        />

        <Tabs defaultValue="all">
          <TabsList className="bg-yellow-950/30 border border-yellow-500/20">
            <TabsTrigger value="all" className="data-[state=active]:bg-yellow-500 data-[state=active]:text-black">All</TabsTrigger>
            <TabsTrigger value="fashion" className="data-[state=active]:bg-yellow-500 data-[state=active]:text-black">Fashion</TabsTrigger>
            <TabsTrigger value="entertainment" className="data-[state=active]:bg-yellow-500 data-[state=active]:text-black">Entertainment</TabsTrigger>
            <TabsTrigger value="sports" className="data-[state=active]:bg-yellow-500 data-[state=active]:text-black">Sports</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="mt-4">
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {filteredCelebrities.map((celeb) => (
                <div
                  key={celeb._id}
                  className="bg-gradient-to-b from-yellow-950/30 to-black rounded-xl border border-yellow-500/20 overflow-hidden hover:border-yellow-500/40 transition-all group"
                >
                  <div className="aspect-square relative">
                    <img
                      src={celeb.image}
                      alt={celeb.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                    <div className="absolute bottom-2 left-2 right-2">
                      <h3 className="font-bold text-yellow-100 text-sm">{celeb.name}</h3>
                      <p className="text-xs text-yellow-500/60">@{celeb.username}</p>
                    </div>
                    {celeb.isVerified && (
                      <div className="absolute top-2 right-2 w-6 h-6 bg-yellow-500 rounded-full flex items-center justify-center">
                        <Crown className="w-3 h-3 text-black" />
                      </div>
                    )}
                  </div>
                  <div className="p-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-yellow-500/60 flex items-center gap-1">
                        <Users className="w-3 h-3" />
                        {formatFollowers(celeb.followers)}
                      </span>
                      <div className="flex gap-1">
                        {celeb.instagram && (
                          <a
                            href={celeb.instagram}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="w-7 h-7 bg-purple-600 rounded flex items-center justify-center text-white"
                          >
                            <Instagram className="w-3 h-3" />
                          </a>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>

          {['fashion', 'entertainment', 'sports'].map((cat) => (
            <TabsContent key={cat} value={cat} className="mt-4">
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {filteredCelebrities
                  .filter(c => c.category === cat)
                  .map((celeb) => (
                    <div
                      key={celeb._id}
                      className="bg-gradient-to-b from-yellow-950/30 to-black rounded-xl border border-yellow-500/20 overflow-hidden hover:border-yellow-500/40 transition-all group"
                    >
                      <div className="aspect-square relative">
                        <img
                          src={celeb.image}
                          alt={celeb.name}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                        <div className="absolute bottom-2 left-2 right-2">
                          <h3 className="font-bold text-yellow-100 text-sm">{celeb.name}</h3>
                          <p className="text-xs text-yellow-500/60">@{celeb.username}</p>
                        </div>
                      </div>
                      <div className="p-3">
                        <div className="flex items-center justify-between">
                          <span className="text-xs text-yellow-500/60 flex items-center gap-1">
                            <Users className="w-3 h-3" />
                            {formatFollowers(celeb.followers)}
                          </span>
                          {celeb.instagram && (
                            <a
                              href={celeb.instagram}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="w-7 h-7 bg-purple-600 rounded flex items-center justify-center text-white"
                            >
                              <Instagram className="w-3 h-3" />
                            </a>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </div>
  );
};
