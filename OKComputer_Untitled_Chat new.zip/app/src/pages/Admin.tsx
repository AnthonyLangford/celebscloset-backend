import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Crown, Users, ShoppingBag, DollarSign, TrendingUp, Check, Star, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useAuth } from '@/context/AuthContext';

const DEMO_STATS = {
  totalUsers: 1247,
  totalProducts: 856,
  totalOrders: 2341,
  totalRevenue: 45678.90
};

const DEMO_USERS = [
  { id: '1', username: 'luxurydealer', email: 'dealer@example.com', fullName: 'Luxury Dealer', isVerified: true, isCelebrity: true, avatar: '/logo.jpg' },
  { id: '2', username: 'fashionista', email: 'fashion@example.com', fullName: 'Fashionista', isVerified: true, isCelebrity: false, avatar: '/logo.jpg' },
  { id: '3', username: 'newuser', email: 'new@example.com', fullName: 'New User', isVerified: false, isCelebrity: false, avatar: '/logo.jpg' },
];

const DEMO_PRODUCTS = [
  { _id: '1', title: 'Designer Handbag', price: 2500, category: 'fashion', status: 'active', images: ['https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=100'] },
  { _id: '2', title: 'Vintage Rolex', price: 15000, category: 'accessories', status: 'active', images: ['https://images.unsplash.com/photo-1524592094714-0f0654e20314?w=100'] },
];

const DEMO_ORDERS = [
  { _id: 'order1', amount: 2500, platformFee: 250, status: 'paid' },
  { _id: 'order2', amount: 15000, platformFee: 1500, status: 'pending' },
];

export const Admin: React.FC = () => {
  const navigate = useNavigate();
  const { user } = useAuth();

  if (!user?.isCEO) {
    navigate('/');
    return null;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-yellow-400 to-yellow-600 flex items-center justify-center shadow-[0_0_20px_rgba(234,179,8,0.4)]">
          <Crown className="w-6 h-6 text-black" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 to-yellow-500">
            CEO Dashboard
          </h1>
          <p className="text-yellow-500/60">Welcome back, Anthony Langford</p>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-gradient-to-b from-yellow-950/30 to-black rounded-xl p-4 border border-yellow-500/20">
          <div className="flex items-center gap-3 mb-2">
            <Users className="w-5 h-5 text-yellow-400" />
            <span className="text-sm text-yellow-500/60">Total Users</span>
          </div>
          <p className="text-2xl font-bold text-yellow-100">{DEMO_STATS.totalUsers.toLocaleString()}</p>
        </div>
        <div className="bg-gradient-to-b from-yellow-950/30 to-black rounded-xl p-4 border border-yellow-500/20">
          <div className="flex items-center gap-3 mb-2">
            <ShoppingBag className="w-5 h-5 text-yellow-400" />
            <span className="text-sm text-yellow-500/60">Products</span>
          </div>
          <p className="text-2xl font-bold text-yellow-100">{DEMO_STATS.totalProducts.toLocaleString()}</p>
        </div>
        <div className="bg-gradient-to-b from-yellow-950/30 to-black rounded-xl p-4 border border-yellow-500/20">
          <div className="flex items-center gap-3 mb-2">
            <TrendingUp className="w-5 h-5 text-yellow-400" />
            <span className="text-sm text-yellow-500/60">Orders</span>
          </div>
          <p className="text-2xl font-bold text-yellow-100">{DEMO_STATS.totalOrders.toLocaleString()}</p>
        </div>
        <div className="bg-gradient-to-b from-yellow-950/30 to-black rounded-xl p-4 border border-yellow-500/20">
          <div className="flex items-center gap-3 mb-2">
            <DollarSign className="w-5 h-5 text-yellow-400" />
            <span className="text-sm text-yellow-500/60">Revenue (10%)</span>
          </div>
          <p className="text-2xl font-bold text-yellow-100">${DEMO_STATS.totalRevenue.toLocaleString()}</p>
        </div>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="users">
        <TabsList className="bg-yellow-950/30 border border-yellow-500/20">
          <TabsTrigger value="users" className="data-[state=active]:bg-yellow-500 data-[state=active]:text-black">
            <Users className="w-4 h-4 mr-1" />
            Users
          </TabsTrigger>
          <TabsTrigger value="products" className="data-[state=active]:bg-yellow-500 data-[state=active]:text-black">
            <ShoppingBag className="w-4 h-4 mr-1" />
            Products
          </TabsTrigger>
          <TabsTrigger value="orders" className="data-[state=active]:bg-yellow-500 data-[state=active]:text-black">
            <TrendingUp className="w-4 h-4 mr-1" />
            Orders
          </TabsTrigger>
        </TabsList>

        <TabsContent value="users" className="mt-4">
          <div className="space-y-2">
            {DEMO_USERS.map((u) => (
              <div
                key={u.id}
                className="flex items-center justify-between p-4 bg-gradient-to-b from-yellow-950/30 to-black rounded-xl border border-yellow-500/20"
              >
                <div className="flex items-center gap-3">
                  <Avatar className="border border-yellow-500/30">
                    <AvatarImage src={u.avatar} />
                    <AvatarFallback className="bg-yellow-950 text-yellow-400">{u.username[0]}</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-yellow-100">{u.username}</span>
                      {u.isVerified && <Badge className="bg-yellow-500/20 text-yellow-400 border border-yellow-500/30">Verified</Badge>}
                      {u.isCelebrity && <Badge className="bg-gradient-to-r from-yellow-600 to-yellow-500 text-black">Celebrity</Badge>}
                    </div>
                    <p className="text-sm text-yellow-500/60">{u.email}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {!u.isVerified && (
                    <Button size="sm" variant="outline" className="border-yellow-500/30 text-yellow-400 hover:bg-yellow-500/10">
                      <Check className="w-4 h-4 mr-1" />
                      Verify
                    </Button>
                  )}
                  {!u.isCelebrity && (
                    <Button size="sm" variant="outline" className="border-yellow-500/30 text-yellow-400 hover:bg-yellow-500/10">
                      <Star className="w-4 h-4 mr-1" />
                      Make Celebrity
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="products" className="mt-4">
          <div className="space-y-2">
            {DEMO_PRODUCTS.map((product) => (
              <div
                key={product._id}
                className="flex items-center justify-between p-4 bg-gradient-to-b from-yellow-950/30 to-black rounded-xl border border-yellow-500/20"
              >
                <div className="flex items-center gap-3">
                  <img
                    src={product.images[0] || '/logo.jpg'}
                    alt={product.title}
                    className="w-12 h-12 rounded-lg object-cover border border-yellow-500/30"
                  />
                  <div>
                    <p className="font-medium text-yellow-100">{product.title}</p>
                    <p className="text-sm text-yellow-500/60">
                      ${product.price.toLocaleString()} • {product.category} • {product.status}
                    </p>
                  </div>
                </div>
                <Button size="sm" variant="destructive" className="bg-red-500/20 text-red-400 border border-red-500/30 hover:bg-red-500/30">
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="orders" className="mt-4">
          <div className="space-y-2">
            {DEMO_ORDERS.map((order) => (
              <div
                key={order._id}
                className="p-4 bg-gradient-to-b from-yellow-950/30 to-black rounded-xl border border-yellow-500/20"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium text-yellow-100">Order #{order._id.slice(-6)}</p>
                    <p className="text-sm text-yellow-500/60">
                      Amount: ${order.amount.toLocaleString()} • Fee: ${order.platformFee.toLocaleString()}
                    </p>
                  </div>
                  <Badge className={order.status === 'paid' ? 'bg-green-500/20 text-green-400 border border-green-500/30' : 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/30'}>
                    {order.status}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};
