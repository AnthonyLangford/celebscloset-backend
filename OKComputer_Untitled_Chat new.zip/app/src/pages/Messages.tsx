import React, { useState } from 'react';
import { Send, Phone, Video, MoreVertical, Image, Smile, Paperclip, MessageCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useAuth } from '@/context/AuthContext';
import type { Message, User } from '@/types';

const DEMO_CONVERSATIONS: { user: User; lastMessage: Message; unread: number }[] = [
  {
    user: {
      id: 'user1',
      _id: 'user1',
      username: 'luxurydealer',
      email: 'dealer@example.com',
      fullName: 'Luxury Dealer',
      avatar: '/logo.jpg',
      bio: '',
      isVerified: true,
      isCelebrity: true,
      isAdmin: false,
      isCEO: false,
      followers: [],
      following: [],
      socialLinks: {},
      balance: 0
    },
    lastMessage: {
      _id: 'msg1',
      senderId: {} as User,
      receiverId: {} as User,
      content: 'Is this item still available?',
      isRead: false,
      createdAt: new Date().toISOString()
    },
    unread: 2
  },
  {
    user: {
      id: 'user2',
      _id: 'user2',
      username: 'fashionista',
      email: 'fashion@example.com',
      fullName: 'Fashionista',
      avatar: '/logo.jpg',
      bio: '',
      isVerified: true,
      isCelebrity: false,
      isAdmin: false,
      isCEO: false,
      followers: [],
      following: [],
      socialLinks: {},
      balance: 0
    },
    lastMessage: {
      _id: 'msg2',
      senderId: {} as User,
      receiverId: {} as User,
      content: 'Thanks for the purchase!',
      isRead: true,
      createdAt: new Date(Date.now() - 3600000).toISOString()
    },
    unread: 0
  }
];

const DEMO_MESSAGES: Message[] = [
  {
    _id: 'm1',
    senderId: {
      id: 'user1',
      _id: 'user1',
      username: 'luxurydealer',
      email: 'dealer@example.com',
      fullName: 'Luxury Dealer',
      avatar: '/logo.jpg',
      bio: '',
      isVerified: true,
      isCelebrity: true,
      isAdmin: false,
      isCEO: false,
      followers: [],
      following: [],
      socialLinks: {},
      balance: 0
    },
    receiverId: {} as User,
    content: 'Hi! How can I help you today?',
    isRead: true,
    createdAt: new Date(Date.now() - 7200000).toISOString()
  },
  {
    _id: 'm2',
    senderId: {} as User,
    receiverId: {} as User,
    content: 'Is this item still available?',
    isRead: true,
    createdAt: new Date(Date.now() - 3600000).toISOString()
  }
];

export const Messages: React.FC = () => {
  const { user } = useAuth();
  const [conversations] = useState(DEMO_CONVERSATIONS);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [messages] = useState<Message[]>(DEMO_MESSAGES);
  const [newMessage, setNewMessage] = useState('');

  const handleSendMessage = () => {
    if (!newMessage.trim()) return;
    setNewMessage('');
  };

  return (
    <div className="h-[calc(100vh-8rem)] bg-gradient-to-b from-yellow-950/20 to-black rounded-xl border border-yellow-500/20 overflow-hidden">
      <div className="flex h-full">
        {/* Conversations List */}
        <div className="w-full md:w-80 border-r border-yellow-500/20 flex flex-col">
          <div className="p-4 border-b border-yellow-500/20">
            <h2 className="text-lg font-semibold text-yellow-100">Messages</h2>
            <p className="text-sm text-green-500/70">Online</p>
          </div>
          <ScrollArea className="flex-1">
            {conversations.map((conv) => (
              <button
                key={conv.user.id}
                onClick={() => setSelectedUser(conv.user)}
                className={`w-full p-4 flex items-center gap-3 hover:bg-yellow-500/5 transition-colors text-left ${
                  selectedUser?.id === conv.user.id ? 'bg-yellow-500/10' : ''
                }`}
              >
                <div className="relative">
                  <Avatar className="border border-yellow-500/30">
                    <AvatarImage src={conv.user.avatar} />
                    <AvatarFallback className="bg-yellow-950 text-yellow-400">{conv.user.username[0]}</AvatarFallback>
                  </Avatar>
                  {conv.unread > 0 && (
                    <span className="absolute -top-1 -right-1 w-5 h-5 bg-gradient-to-r from-yellow-500 to-yellow-600 rounded-full text-xs flex items-center justify-center text-black font-bold">
                      {conv.unread}
                    </span>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <p className="font-medium truncate text-yellow-100">{conv.user.username}</p>
                    <span className="text-xs text-yellow-500/40">
                      {new Date(conv.lastMessage.createdAt).toLocaleTimeString([], {
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </span>
                  </div>
                  <p className="text-sm text-yellow-500/60 truncate">
                    {conv.lastMessage.content}
                  </p>
                </div>
              </button>
            ))}
          </ScrollArea>
        </div>

        {/* Chat Area */}
        <div className="hidden md:flex flex-1 flex-col">
          {selectedUser ? (
            <>
              {/* Chat Header */}
              <div className="p-4 border-b border-yellow-500/20 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Avatar className="border border-yellow-500/30">
                    <AvatarImage src={selectedUser.avatar} />
                    <AvatarFallback className="bg-yellow-950 text-yellow-400">{selectedUser.username[0]}</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium text-yellow-100">{selectedUser.username}</p>
                    <p className="text-sm text-green-500/70">Online</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Button variant="ghost" size="icon" className="text-yellow-500/60 hover:text-yellow-400">
                    <Phone className="w-5 h-5" />
                  </Button>
                  <Button variant="ghost" size="icon" className="text-yellow-500/60 hover:text-yellow-400">
                    <Video className="w-5 h-5" />
                  </Button>
                  <Button variant="ghost" size="icon" className="text-yellow-500/60 hover:text-yellow-400">
                    <MoreVertical className="w-5 h-5" />
                  </Button>
                </div>
              </div>

              {/* Messages */}
              <ScrollArea className="flex-1 p-4">
                <div className="space-y-4">
                  {messages.map((msg) => {
                    const isMe = msg.senderId._id === user?.id;
                    return (
                      <div
                        key={msg._id}
                        className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}
                      >
                        <div
                          className={`max-w-[70%] px-4 py-2 rounded-2xl ${
                            isMe
                              ? 'bg-gradient-to-r from-yellow-600 to-yellow-500 text-black rounded-br-sm font-medium'
                              : 'bg-yellow-950/50 text-yellow-100 rounded-bl-sm border border-yellow-500/20'
                          }`}
                        >
                          <p>{msg.content}</p>
                          <span className="text-xs opacity-70 mt-1 block">
                            {new Date(msg.createdAt).toLocaleTimeString([], {
                              hour: '2-digit',
                              minute: '2-digit'
                            })}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </ScrollArea>

              {/* Input Area */}
              <div className="p-4 border-t border-yellow-500/20">
                <div className="flex items-center gap-2">
                  <Button variant="ghost" size="icon" className="text-yellow-500/60 hover:text-yellow-400">
                    <Paperclip className="w-5 h-5" />
                  </Button>
                  <Button variant="ghost" size="icon" className="text-yellow-500/60 hover:text-yellow-400">
                    <Image className="w-5 h-5" />
                  </Button>
                  <Input
                    placeholder="Type a message..."
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                    className="flex-1 bg-yellow-950/30 border-yellow-500/30 text-yellow-100 placeholder:text-yellow-500/40"
                  />
                  <Button variant="ghost" size="icon" className="text-yellow-500/60 hover:text-yellow-400">
                    <Smile className="w-5 h-5" />
                  </Button>
                  <Button
                    onClick={handleSendMessage}
                    disabled={!newMessage.trim()}
                    className="bg-gradient-to-r from-yellow-600 to-yellow-500 text-black font-bold hover:from-yellow-500 hover:to-yellow-400"
                  >
                    <Send className="w-5 h-5" />
                  </Button>
                </div>
              </div>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center text-yellow-500/50">
              <div className="text-center">
                <MessageCircle className="w-16 h-16 mx-auto mb-4 opacity-50" />
                <p className="text-lg">Select a conversation</p>
                <p className="text-sm">Choose someone to start messaging</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
