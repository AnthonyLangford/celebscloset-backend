import React, { useState } from 'react';

import { Search, Filter, Plus, Heart, Clock, TrendingUp, Shirt, Watch, Film, Home, Car } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import type { Product } from '@/types';



const DEMO_PRODUCTS: Product[] = [
  {
    _id: '1',
    sellerId: {
      id: 'seller1',
      _id: 'seller1',
      username: 'luxurydealer',
      email: 'dealer@example.com',
      fullName: 'Luxury Dealer',
      avatar: '/logo.jpg',
      bio: '',
      isVerified: true,
      isCelebrity: true,
      isAdmin: false,
      isCEO: false,
      followers: [],
      following: [],
      socialLinks: {},
      balance: 0
    },
    title: 'Designer Handbag - Limited Edition',
    description: 'Authentic luxury handbag in pristine condition',
    price: 2500,
    category: 'fashion',
    subcategory: 'bags',
    images: ['https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=400'],
    condition: 'like-new',
    isAuction: false,
    currentBid: 0,
    startingBid: 0,
    status: 'active',
    createdAt: new Date().toISOString()
  },
  {
    _id: '2',
    sellerId: {
      id: 'seller2',
      _id: 'seller2',
      username: 'watchcollector',
      email: 'watch@example.com',
      fullName: 'Watch Collector',
      avatar: '/logo.jpg',
      bio: '',
      isVerified: true,
      isCelebrity: false,
      isAdmin: false,
      isCEO: false,
      followers: [],
      following: [],
      socialLinks: {},
      balance: 0
    },
    title: 'Vintage Rolex Submariner',
    description: 'Classic timepiece, fully serviced',
    price: 15000,
    category: 'accessories',
    subcategory: 'watches',
    images: ['https://images.unsplash.com/photo-1524592094714-0f0654e20314?w=400'],
    condition: 'good',
    isAuction: true,
    auctionEndTime: new Date(Date.now() + 48 * 60 * 60 * 1000).toISOString(),
    currentBid: 15200,
    startingBid: 15000,
    status: 'active',
    createdAt: new Date().toISOString()
  },
  {
    _id: '3',
    sellerId: {
      id: 'seller3',
      _id: 'seller3',
      username: 'realestatepro',
      email: 'realestate@example.com',
      fullName: 'Real Estate Pro',
      avatar: '/logo.jpg',
      bio: '',
      isVerified: true,
      isCelebrity: false,
      isAdmin: false,
      isCEO: false,
      followers: [],
      following: [],
      socialLinks: {},
      balance: 0
    },
    title: 'Luxury Penthouse - Downtown',
    description: 'Stunning penthouse with city views',
    price: 2500000,
    category: 'real-estate',
    subcategory: 'penthouse',
    images: ['https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=400'],
    condition: 'new',
    isAuction: false,
    currentBid: 0,
    startingBid: 0,
    status: 'active',
    createdAt: new Date().toISOString()
  }
];

const CATEGORIES = [
  { id: 'fashion', name: 'Fashion', icon: Shirt },
  { id: 'accessories', name: 'Accessories', icon: Watch },
  { id: 'entertainment', name: 'Entertainment', icon: Film },
  { id: 'real-estate', name: 'Real Estate', icon: Home },
  { id: 'automotive', name: 'Automotive', icon: Car },
];

export const Marketplace: React.FC = () => {
  const [products] = useState<Product[]>(DEMO_PRODUCTS);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [showSellDialog, setShowSellDialog] = useState(false);

  const filteredProducts = selectedCategory === 'all' 
    ? products 
    : products.filter(p => p.category === selectedCategory);

  const formatTimeLeft = (endTime: string) => {
    const diff = new Date(endTime).getTime() - Date.now();
    if (diff <= 0) return 'Ended';
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    return `${hours}h ${minutes}m`;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 to-yellow-500">
          Marketplace
        </h1>
        <Button
          onClick={() => setShowSellDialog(true)}
          className="bg-gradient-to-r from-yellow-600 to-yellow-500 text-black font-bold hover:from-yellow-500 hover:to-yellow-400"
        >
          <Plus className="w-4 h-4 mr-2" />
          Sell Item
        </Button>
      </div>

      {/* Search */}
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-yellow-500/50" />
          <Input
            placeholder="Search luxury items..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 bg-yellow-950/30 border-yellow-500/30 text-yellow-100 placeholder:text-yellow-500/40"
          />
        </div>
        <Button variant="outline" className="border-yellow-500/30 text-yellow-400 hover:bg-yellow-500/10">
          <Filter className="w-4 h-4" />
        </Button>
      </div>

      {/* Categories */}
      <div className="flex gap-2 overflow-x-auto pb-2">
        <Button
          variant={selectedCategory === 'all' ? 'default' : 'outline'}
          size="sm"
          onClick={() => setSelectedCategory('all')}
          className={selectedCategory === 'all' 
            ? 'bg-gradient-to-r from-yellow-600 to-yellow-500 text-black font-bold' 
            : 'border-yellow-500/30 text-yellow-400 hover:bg-yellow-500/10'}
        >
          All
        </Button>
        {CATEGORIES.map((cat) => {
          const Icon = cat.icon;
          return (
            <Button
              key={cat.id}
              variant={selectedCategory === cat.id ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedCategory(cat.id)}
              className={selectedCategory === cat.id 
                ? 'bg-gradient-to-r from-yellow-600 to-yellow-500 text-black font-bold' 
                : 'border-yellow-500/30 text-yellow-400 hover:bg-yellow-500/10'}
            >
              <Icon className="w-4 h-4 mr-1" />
              {cat.name}
            </Button>
          );
        })}
      </div>

      {/* Tabs */}
      <Tabs defaultValue="all">
        <TabsList className="bg-yellow-950/30 border border-yellow-500/20">
          <TabsTrigger value="all" className="data-[state=active]:bg-yellow-500 data-[state=active]:text-black">All Items</TabsTrigger>
          <TabsTrigger value="auctions" className="data-[state=active]:bg-yellow-500 data-[state=active]:text-black">Auctions</TabsTrigger>
          <TabsTrigger value="trending" className="data-[state=active]:bg-yellow-500 data-[state=active]:text-black">Trending</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="mt-4">
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {filteredProducts.map((product) => (
              <div
                key={product._id}
                className="bg-gradient-to-b from-yellow-950/30 to-black rounded-xl border border-yellow-500/20 overflow-hidden hover:border-yellow-500/40 transition-all cursor-pointer group"
              >
                <div className="aspect-square relative">
                  <img
                    src={product.images[0] || '/logo.jpg'}
                    alt={product.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                  />
                  {product.isAuction && (
                    <div className="absolute top-2 left-2 bg-gradient-to-r from-red-600 to-red-500 text-white text-xs px-2 py-1 rounded-full flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {formatTimeLeft(product.auctionEndTime!)}
                    </div>
                  )}
                  <Button
                    variant="ghost"
                    size="icon"
                    className="absolute top-2 right-2 bg-black/50 text-yellow-400 opacity-0 group-hover:opacity-100 transition-opacity border border-yellow-500/30"
                  >
                    <Heart className="w-4 h-4" />
                  </Button>
                </div>
                <div className="p-3">
                  <h3 className="font-medium text-sm line-clamp-1 text-yellow-100">{product.title}</h3>
                  <p className="text-xs text-yellow-500/60 line-clamp-1">@{product.sellerId.username}</p>
                  <div className="flex items-center justify-between mt-2">
                    <div>
                      {product.isAuction ? (
                        <div>
                          <p className="text-xs text-yellow-500/60">Current bid</p>
                          <p className="font-bold text-yellow-400">${product.currentBid.toLocaleString()}</p>
                        </div>
                      ) : (
                        <p className="font-bold text-yellow-400">${product.price.toLocaleString()}</p>
                      )}
                    </div>
                    <Badge variant="secondary" className="text-xs bg-yellow-500/20 text-yellow-400 border border-yellow-500/30">
                      {product.condition}
                    </Badge>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="auctions" className="mt-4">
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {filteredProducts.filter(p => p.isAuction).map((product) => (
              <div
                key={product._id}
                className="bg-gradient-to-b from-yellow-950/30 to-black rounded-xl border border-yellow-500/20 overflow-hidden hover:border-yellow-500/40 transition-all cursor-pointer"
              >
                <div className="aspect-square relative">
                  <img
                    src={product.images[0] || '/logo.jpg'}
                    alt={product.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-2 left-2 bg-gradient-to-r from-red-600 to-red-500 text-white text-xs px-2 py-1 rounded-full flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {formatTimeLeft(product.auctionEndTime!)}
                  </div>
                </div>
                <div className="p-3">
                  <h3 className="font-medium text-sm line-clamp-1 text-yellow-100">{product.title}</h3>
                  <p className="text-xs text-yellow-500/60">Current bid: ${product.currentBid.toLocaleString()}</p>
                  <Button
                    size="sm"
                    className="w-full mt-2 bg-gradient-to-r from-yellow-600 to-yellow-500 text-black font-bold hover:from-yellow-500 hover:to-yellow-400"
                  >
                    Place Bid
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="trending" className="mt-4">
          <div className="flex items-center justify-center h-32 text-yellow-500/50">
            <TrendingUp className="w-5 h-5 mr-2" />
            Trending items coming soon
          </div>
        </TabsContent>
      </Tabs>

      {/* Sell Dialog */}
      <Dialog open={showSellDialog} onOpenChange={setShowSellDialog}>
        <DialogContent className="bg-black border-yellow-500/30 text-yellow-100 max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-yellow-400">Sell an Item</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <Input
              placeholder="Title"
              className="bg-yellow-950/30 border-yellow-500/30 text-yellow-100 placeholder:text-yellow-500/40"
            />
            <textarea
              placeholder="Description"
              className="w-full p-3 bg-yellow-950/30 border border-yellow-500/30 rounded-lg text-yellow-100 placeholder:text-yellow-500/40 resize-none"
              rows={3}
            />
            <div className="grid grid-cols-2 gap-4">
              <Input
                type="number"
                placeholder="Price"
                className="bg-yellow-950/30 border-yellow-500/30 text-yellow-100 placeholder:text-yellow-500/40"
              />
              <select className="p-2 bg-yellow-950/30 border border-yellow-500/30 rounded-lg text-yellow-100">
                {CATEGORIES.map((cat) => (
                  <option key={cat.id} value={cat.id}>{cat.name}</option>
                ))}
              </select>
            </div>
            <Button
              className="w-full bg-gradient-to-r from-yellow-600 to-yellow-500 text-black font-bold hover:from-yellow-500 hover:to-yellow-400"
            >
              List Item
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};
