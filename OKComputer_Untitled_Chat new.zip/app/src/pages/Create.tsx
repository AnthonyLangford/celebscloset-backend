import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Image, Video, X, Loader2, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/context/AuthContext';

export const Create: React.FC = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [content, setContent] = useState('');
  const [media, setMedia] = useState<string[]>([]);
  const [isStory, setIsStory] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleMediaSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    Array.from(files).forEach(file => {
      const reader = new FileReader();
      reader.onloadend = () => {
        setMedia(prev => [...prev, reader.result as string]);
      };
      reader.readAsDataURL(file);
    });
  };

  const removeMedia = (index: number) => {
    setMedia(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async () => {
    if (!content.trim() && media.length === 0) return;

    setLoading(true);
    setTimeout(() => {
      navigate('/');
    }, 1000);
  };

  return (
    <div className="max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold mb-6 text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 to-yellow-500">
        Create Post
      </h1>

      <div className="bg-gradient-to-b from-yellow-950/30 to-black rounded-xl border border-yellow-500/20 p-6 space-y-6">
        {/* User Info */}
        <div className="flex items-center gap-3">
          <img
            src={user?.avatar || '/logo.jpg'}
            alt={user?.username}
            className="w-10 h-10 rounded-full border border-yellow-500/30"
          />
          <div>
            <p className="font-semibold text-yellow-100">{user?.username}</p>
            <div className="flex items-center gap-2">
              <label className="flex items-center gap-2 text-sm text-yellow-500/60 cursor-pointer">
                <input
                  type="checkbox"
                  checked={isStory}
                  onChange={(e) => setIsStory(e.target.checked)}
                  className="rounded border-yellow-500/30 bg-yellow-950/30"
                />
                Post as Story (24h)
              </label>
            </div>
          </div>
        </div>

        {/* Content Input */}
        <textarea
          placeholder="What's on your mind?"
          value={content}
          onChange={(e) => setContent(e.target.value)}
          className="w-full p-4 bg-yellow-950/30 border border-yellow-500/30 rounded-xl text-yellow-100 placeholder:text-yellow-500/40 resize-none min-h-[150px]"
        />

        {/* Media Preview */}
        {media.length > 0 && (
          <div className="grid grid-cols-3 gap-2">
            {media.map((item, idx) => (
              <div key={idx} className="relative aspect-square">
                <img src={item} alt="" className="w-full h-full object-cover rounded-lg border border-yellow-500/30" />
                <button
                  onClick={() => removeMedia(idx)}
                  className="absolute top-1 right-1 w-6 h-6 bg-black/80 border border-yellow-500/30 rounded-full flex items-center justify-center text-yellow-400 hover:bg-yellow-500/20"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Media Options */}
        <div className="flex items-center gap-4 pt-4 border-t border-yellow-500/20">
          <label className="flex items-center gap-2 text-yellow-500/60 hover:text-yellow-400 cursor-pointer transition-colors">
            <Image className="w-5 h-5" />
            <span className="text-sm">Photo</span>
            <input
              type="file"
              accept="image/*"
              multiple
              className="hidden"
              onChange={(e) => handleMediaSelect(e)}
            />
          </label>
          <label className="flex items-center gap-2 text-yellow-500/60 hover:text-yellow-400 cursor-pointer transition-colors">
            <Video className="w-5 h-5" />
            <span className="text-sm">Video</span>
            <input
              type="file"
              accept="video/*"
              className="hidden"
              onChange={(e) => handleMediaSelect(e)}
            />
          </label>
        </div>

        {/* Submit */}
        <Button
          onClick={handleSubmit}
          disabled={(!content.trim() && media.length === 0) || loading}
          className="w-full bg-gradient-to-r from-yellow-600 to-yellow-500 text-black font-bold py-6 hover:from-yellow-500 hover:to-yellow-400 shadow-[0_0_20px_rgba(234,179,8,0.4)]"
        >
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Posting...
            </>
          ) : (
            'Post'
          )}
        </Button>
      </div>

      {/* Decorative */}
      <div className="flex justify-center gap-2 mt-6">
        <Sparkles className="w-4 h-4 text-yellow-500/30" />
        <span className="text-yellow-500/30 text-xs">Share your luxury lifestyle</span>
        <Sparkles className="w-4 h-4 text-yellow-500/30" />
      </div>
    </div>
  );
};
