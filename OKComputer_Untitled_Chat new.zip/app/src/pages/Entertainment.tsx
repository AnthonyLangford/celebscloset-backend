import React, { useState, useEffect } from 'react';
import { Play, Heart, Radio, Calendar, Ticket, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

import { VideoPlayer } from '@/components/VideoPlayer';
import { useAuth } from '@/context/AuthContext';

interface Video {
  _id: string;
  title: string;
  description: string;
  videoUrl: string;
  thumbnail: string;
  userId: {
    _id: string;
    username: string;
    fullName: string;
    avatar: string;
    isVerified: boolean;
  };
  likes: string[];
  comments: any[];
  views: number;
  isReel: boolean;
  isStory: boolean;
  createdAt: string;
}

interface Event {
  _id: string;
  title: string;
  description: string;
  venue: string;
  date: string;
  ticketPrice: number;
  totalTickets: number;
  soldTickets: number;
  image: string;
  celebrityId: {
    username: string;
    avatar: string;
    isVerified: boolean;
  };
}

export const Entertainment: React.FC = () => {
  const { user } = useAuth();
  const [reels, setReels] = useState<Video[]>([]);
  const [stories, setStories] = useState<Video[]>([]);
  const [events, setEvents] = useState<Event[]>([]);
  const [activeVideo, setActiveVideo] = useState<Video | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchReels();
    fetchStories();
    fetchEvents();
  }, []);

  const fetchReels = async () => {
    try {
      const res = await fetch('/api/videos/reels', {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      });
      const data = await res.json();
      setReels(data);
    } catch (error) {
      console.error('Error fetching reels:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchStories = async () => {
    try {
      const res = await fetch('/api/videos/stories', {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      });
      const data = await res.json();
      setStories(data);
    } catch (error) {
      console.error('Error fetching stories:', error);
    }
  };

  const fetchEvents = async () => {
    try {
      const res = await fetch('/api/events/upcoming', {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      });
      const data = await res.json();
      setEvents(data);
    } catch (error) {
      console.error('Error fetching events:', error);
    }
  };

  const handleLike = async (videoId: string) => {
    try {
      const res = await fetch(`/api/videos/${videoId}/like`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      });
      if (res.ok) {
        fetchReels();
      }
    } catch (error) {
      console.error('Error liking video:', error);
    }
  };

  const handleShare = async (videoId: string, platform: string) => {
    try {
      await fetch(`/api/videos/${videoId}/share`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify({ platform })
      });
    } catch (error) {
      console.error('Error sharing video:', error);
    }
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin w-8 h-8 border-4 border-yellow-500 border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 to-yellow-500">
          Entertainment
        </h1>
        <Button className="bg-gradient-to-r from-yellow-600 to-yellow-500 text-black font-bold">
          <Plus className="w-4 h-4 mr-2" />
          Upload Video
        </Button>
      </div>

      <Tabs defaultValue="reels">
        <TabsList className="bg-yellow-950/30 border border-yellow-500/20">
          <TabsTrigger value="reels" className="data-[state=active]:bg-yellow-500 data-[state=active]:text-black">
            <Play className="w-4 h-4 mr-1" />
            Reels
          </TabsTrigger>
          <TabsTrigger value="stories" className="data-[state=active]:bg-yellow-500 data-[state=active]:text-black">
            <Radio className="w-4 h-4 mr-1" />
            Stories
          </TabsTrigger>
          <TabsTrigger value="events" className="data-[state=active]:bg-yellow-500 data-[state=active]:text-black">
            <Calendar className="w-4 h-4 mr-1" />
            Events
          </TabsTrigger>
        </TabsList>

        {/* Reels Tab */}
        <TabsContent value="reels" className="mt-4">
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {reels.map((reel) => (
              <div
                key={reel._id}
                className="relative aspect-[9/16] bg-black rounded-xl overflow-hidden cursor-pointer group border border-yellow-500/20 hover:border-yellow-500/40"
                onClick={() => setActiveVideo(reel)}
              >
                <img
                  src={reel.thumbnail || '/logo.jpg'}
                  alt={reel.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent" />
                
                {/* Play Button */}
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="w-16 h-16 bg-yellow-500/80 rounded-full flex items-center justify-center">
                    <Play className="w-8 h-8 text-black ml-1" />
                  </div>
                </div>

                <div className="absolute bottom-0 left-0 right-0 p-3">
                  <div className="flex items-center gap-2 mb-2">
                    <img
                      src={reel.userId?.avatar || '/logo.jpg'}
                      alt={reel.userId?.username}
                      className="w-8 h-8 rounded-full border border-yellow-500/50"
                    />
                    <div>
                      <p className="text-sm font-medium text-yellow-100">{reel.userId?.username}</p>
                    </div>
                  </div>
                  <p className="text-sm text-yellow-100/80 line-clamp-2">{reel.title}</p>
                  <div className="flex items-center gap-3 mt-2 text-xs text-yellow-500/60">
                    <span className="flex items-center gap-1">
                      <Play className="w-3 h-3" />
                      {reel.views?.toLocaleString() || 0}
                    </span>
                    <span className="flex items-center gap-1">
                      <Heart className="w-3 h-3" />
                      {reel.likes?.length || 0}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </TabsContent>

        {/* Stories Tab */}
        <TabsContent value="stories" className="mt-4">
          <div className="flex gap-4 overflow-x-auto pb-4">
            {/* Add Story Button */}
            <div className="flex-shrink-0 flex flex-col items-center gap-2">
              <div className="w-20 h-32 bg-gradient-to-b from-yellow-950/30 to-black rounded-xl border-2 border-dashed border-yellow-500/50 flex items-center justify-center cursor-pointer hover:bg-yellow-500/10">
                <Plus className="w-8 h-8 text-yellow-500" />
              </div>
              <span className="text-xs text-yellow-500/60">Add Story</span>
            </div>

            {stories.map((story) => (
              <div
                key={story._id}
                className="flex-shrink-0 w-20 cursor-pointer"
                onClick={() => setActiveVideo(story)}
              >
                <div className="w-20 h-32 rounded-xl overflow-hidden border-2 border-yellow-500 p-0.5">
                  <img
                    src={story.thumbnail || '/logo.jpg'}
                    alt={story.title}
                    className="w-full h-full object-cover rounded-lg"
                  />
                </div>
                <p className="text-xs text-yellow-500/60 text-center mt-1 truncate">
                  {story.userId?.username}
                </p>
              </div>
            ))}
          </div>
        </TabsContent>

        {/* Events Tab */}
        <TabsContent value="events" className="mt-4">
          <div className="space-y-4">
            {events.map((event) => (
              <div
                key={event._id}
                className="bg-gradient-to-b from-yellow-950/30 to-black rounded-xl border border-yellow-500/20 overflow-hidden flex flex-col md:flex-row"
              >
                <div className="md:w-48 h-48 md:h-auto relative">
                  <img
                    src={event.image || '/logo.jpg'}
                    alt={event.title}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex-1 p-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <img
                          src={event.celebrityId?.avatar || '/logo.jpg'}
                          alt={event.celebrityId?.username}
                          className="w-6 h-6 rounded-full border border-yellow-500/30"
                        />
                        <span className="text-sm text-yellow-500/60">
                          @{event.celebrityId?.username}
                        </span>
                        {event.celebrityId?.isVerified && (
                          <span className="text-yellow-400 text-xs">★</span>
                        )}
                      </div>
                      <h3 className="text-xl font-semibold text-yellow-100">{event.title}</h3>
                      <p className="text-yellow-500/60 text-sm mt-1">{event.venue}</p>
                      <div className="flex items-center gap-4 mt-2 text-sm text-yellow-500/60">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-4 h-4" />
                          {formatDate(event.date)}
                        </span>
                        <span className="flex items-center gap-1">
                          <Ticket className="w-4 h-4" />
                          {event.soldTickets}/{event.totalTickets} sold
                        </span>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold text-yellow-400">${event.ticketPrice}</p>
                      <Button
                        size="sm"
                        className="mt-2 bg-gradient-to-r from-yellow-600 to-yellow-500 text-black font-bold hover:from-yellow-500 hover:to-yellow-400"
                        disabled={event.soldTickets >= event.totalTickets}
                      >
                        {event.soldTickets >= event.totalTickets ? 'Sold Out' : 'Buy Ticket'}
                      </Button>
                    </div>
                  </div>
                  <p className="text-yellow-200/60 text-sm mt-3 line-clamp-2">
                    {event.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      {/* Video Player Modal */}
      {activeVideo && (
        <div className="fixed inset-0 bg-black z-50 flex items-center justify-center">
          <div className="relative w-full max-w-md h-full max-h-[90vh]">
            <VideoPlayer
              videoUrl={activeVideo.videoUrl}
              thumbnail={activeVideo.thumbnail}
              title={activeVideo.title}
              user={activeVideo.userId}
              onClose={() => setActiveVideo(null)}
              onLike={() => handleLike(activeVideo._id)}
              onShare={(platform) => handleShare(activeVideo._id, platform)}
              isLiked={activeVideo.likes?.includes(user?.id || '')}
              likes={activeVideo.likes?.length || 0}
              comments={activeVideo.comments?.length || 0}
            />
          </div>
        </div>
      )}
    </div>
  );
};
