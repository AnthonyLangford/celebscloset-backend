import React, { useState } from 'react';
import { Search as SearchIcon, TrendingUp, Hash, Crown } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { useNavigate } from 'react-router-dom';

const trendingTopics = [
  '#FashionWeek', '#CelebrityStyle', '#LuxuryLife',
  '#StreetWear', '#DesignerDeals', '#AuctionAlert'
];

const DEMO_USERS = [
  { id: '1', username: 'luxurydealer', fullName: 'Luxury Dealer', isVerified: true, isCelebrity: true },
  { id: '2', username: 'fashionista', fullName: 'Fashionista', isVerified: true, isCelebrity: false },
  { id: '3', username: 'styleicon', fullName: 'Style Icon', isVerified: true, isCelebrity: true },
];

export const Search: React.FC = () => {
  const navigate = useNavigate();
  const [query, setQuery] = useState('');
  const [recentSearches] = useState<string[]>(['luxury', 'fashion', 'celebrity']);

  const filteredUsers = query.trim() 
    ? DEMO_USERS.filter(u => u.username.toLowerCase().includes(query.toLowerCase()))
    : [];

  const handleUserClick = (username: string) => {
    navigate(`/profile/${username}`);
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 to-yellow-500">
        Search
      </h1>

      {/* Search Input */}
      <div className="relative">
        <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-yellow-500/50" />
        <Input
          type="text"
          placeholder="Search users, celebrities, items..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="pl-12 py-6 bg-yellow-950/30 border-yellow-500/30 text-yellow-100 text-lg placeholder:text-yellow-500/40"
          autoFocus
        />
      </div>

      {/* Results */}
      {query.trim() && (
        <div className="space-y-2">
          <h3 className="text-sm font-medium text-yellow-500/60">Users</h3>
          {filteredUsers.length > 0 ? (
            <div className="space-y-2">
              {filteredUsers.map((user) => (
                <button
                  key={user.id}
                  onClick={() => handleUserClick(user.username)}
                  className="w-full flex items-center gap-4 p-3 bg-gradient-to-b from-yellow-950/30 to-black rounded-xl hover:bg-yellow-500/10 transition-colors text-left border border-yellow-500/20"
                >
                  <div className="w-12 h-12 rounded-full border border-yellow-500/30 overflow-hidden">
                    <img src="/logo.jpg" alt={user.username} className="w-full h-full object-cover" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-yellow-100">{user.username}</span>
                      {user.isVerified && <Crown className="w-3 h-3 text-yellow-400" />}
                      {user.isCelebrity && (
                        <span className="text-xs bg-gradient-to-r from-yellow-600 to-yellow-500 text-black px-2 py-0.5 rounded-full font-bold">
                          Celebrity
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-yellow-500/60">{user.fullName}</p>
                  </div>
                </button>
              ))}
            </div>
          ) : (
            <p className="text-yellow-500/50 py-4">No users found</p>
          )}
        </div>
      )}

      {/* Recent Searches */}
      {!query.trim() && recentSearches.length > 0 && (
        <div className="space-y-2">
          <h3 className="text-sm font-medium text-yellow-500/60">Recent</h3>
          <div className="flex flex-wrap gap-2">
            {recentSearches.map((search, idx) => (
              <button
                key={idx}
                onClick={() => setQuery(search)}
                className="px-4 py-2 bg-yellow-950/30 border border-yellow-500/20 rounded-full text-sm text-yellow-400 hover:bg-yellow-500/10 transition-colors"
              >
                {search}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Trending Topics */}
      {!query.trim() && (
        <div className="space-y-2">
          <h3 className="text-sm font-medium text-yellow-500/60 flex items-center gap-2">
            <TrendingUp className="w-4 h-4" />
            Trending
          </h3>
          <div className="flex flex-wrap gap-2">
            {trendingTopics.map((topic, idx) => (
              <button
                key={idx}
                onClick={() => setQuery(topic)}
                className="px-4 py-2 bg-gradient-to-r from-yellow-600/20 to-yellow-500/20 border border-yellow-500/30 rounded-full text-sm text-yellow-400 hover:from-yellow-600/30 hover:to-yellow-500/30 transition-colors"
              >
                <Hash className="w-3 h-3 inline mr-1" />
                {topic.replace('#', '')}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
