import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  Home, 
  ShoppingBag, 
  Play, 
  MessageCircle, 
  User, 
  Crown,
  Search,
  PlusSquare,
  LogOut,
  Menu,
  X
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { Button } from '@/components/ui/button';

export const Sidebar: React.FC = () => {
  const { user, logout } = useAuth();
  const location = useLocation();
  const [isCollapsed, setIsCollapsed] = useState(false);

  const navItems = [
    { path: '/', icon: Home, label: 'Home' },
    { path: '/search', icon: Search, label: 'Search' },
    { path: '/marketplace', icon: ShoppingBag, label: 'Marketplace' },
    { path: '/entertainment', icon: Play, label: 'Entertainment' },
    { path: '/messages', icon: MessageCircle, label: 'Messages' },
    { path: '/create', icon: PlusSquare, label: 'Create' },
    { path: '/profile', icon: User, label: 'Profile' },
  ];

  if (user?.isCEO) {
    navItems.push({ path: '/admin', icon: Crown, label: 'Admin' });
  }

  return (
    <aside 
      className={`fixed left-0 top-0 h-screen bg-gradient-to-b from-yellow-950/20 to-black border-r border-yellow-500/20 z-50 transition-all duration-300 ${
        isCollapsed ? 'w-20' : 'w-64'
      }`}
    >
      <div className="flex flex-col h-full">
        {/* Logo */}
        <div className="flex items-center justify-between p-4 border-b border-yellow-500/20">
          {!isCollapsed && (
            <Link to="/" className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl overflow-hidden border border-yellow-500/50">
                <img src="/logo.jpg" alt="CC" className="w-full h-full object-cover" />
              </div>
              <span className="font-bold text-lg text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 to-yellow-500">
                CelebsCloset
              </span>
            </Link>
          )}
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="text-yellow-500/50 hover:text-yellow-400 hover:bg-yellow-500/10"
          >
            {isCollapsed ? <Menu className="w-5 h-5" /> : <X className="w-5 h-5" />}
          </Button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 py-4">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;
            
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center gap-4 px-4 py-3 mx-2 rounded-xl transition-all ${
                  isActive 
                    ? 'bg-gradient-to-r from-yellow-500/20 to-yellow-600/10 text-yellow-400 border border-yellow-500/30' 
                    : 'text-yellow-500/60 hover:bg-yellow-500/10 hover:text-yellow-300'
                }`}
              >
                <Icon className="w-6 h-6 flex-shrink-0" />
                {!isCollapsed && <span className="font-medium">{item.label}</span>}
              </Link>
            );
          })}
        </nav>

        {/* User Info */}
        <div className="p-4 border-t border-yellow-500/20">
          <div className={`flex items-center gap-3 ${isCollapsed ? 'justify-center' : ''}`}>
            <img
              src={user?.avatar || '/logo.jpg'}
              alt={user?.username}
              className="w-10 h-10 rounded-full border-2 border-yellow-500/50"
            />
            {!isCollapsed && (
              <div className="flex-1 min-w-0">
                <p className="font-medium text-yellow-100 truncate">{user?.fullName}</p>
                <p className="text-sm text-yellow-500/50 truncate">@{user?.username}</p>
              </div>
            )}
            {!isCollapsed && (
              <Button
                variant="ghost"
                size="icon"
                onClick={logout}
                className="text-yellow-500/50 hover:text-red-400 hover:bg-red-500/10"
              >
                <LogOut className="w-5 h-5" />
              </Button>
            )}
          </div>
        </div>
      </div>
    </aside>
  );
};
