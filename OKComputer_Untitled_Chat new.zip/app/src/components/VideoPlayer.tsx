import React, { useRef, useState, useEffect } from 'react';
import { Play, Pause, Volume2, VolumeX, Maximize, Heart, MessageCircle, Share2, X } from 'lucide-react';

interface VideoPlayerProps {
  videoUrl: string;
  thumbnail?: string;
  title?: string;
  user?: any;
  onClose?: () => void;
  onLike?: () => void;
  onComment?: () => void;
  onShare?: (platform: string) => void;
  isLiked?: boolean;
  likes?: number;
  comments?: number;
}

export const VideoPlayer: React.FC<VideoPlayerProps> = ({
  videoUrl,
  thumbnail,
  title,
  user,
  onClose,
  onLike,
  onComment,
  onShare,
  isLiked,
  likes = 0,
  comments = 0
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(true);
  const [progress, setProgress] = useState(0);
  const [showControls, setShowControls] = useState(true);
  const controlsTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const updateProgress = () => {
      const progress = (video.currentTime / video.duration) * 100;
      setProgress(progress);
    };

    video.addEventListener('timeupdate', updateProgress);
    return () => video.removeEventListener('timeupdate', updateProgress);
  }, []);

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const toggleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (videoRef.current) {
      const time = (parseFloat(e.target.value) / 100) * videoRef.current.duration;
      videoRef.current.currentTime = time;
      setProgress(parseFloat(e.target.value));
    }
  };

  const handleFullscreen = () => {
    if (videoRef.current) {
      videoRef.current.requestFullscreen();
    }
  };

  const handleMouseMove = () => {
    setShowControls(true);
    if (controlsTimeoutRef.current) {
      clearTimeout(controlsTimeoutRef.current);
    }
    controlsTimeoutRef.current = setTimeout(() => {
      if (isPlaying) setShowControls(false);
    }, 3000);
  };

  const shareToSocial = (platform: string) => {
    const url = encodeURIComponent(window.location.href);
    const text = encodeURIComponent(title || 'Check out this video on CelebsCloset!');
    
    let shareUrl = '';
    switch (platform) {
      case 'facebook':
        shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${url}`;
        break;
      case 'twitter':
        shareUrl = `https://twitter.com/intent/tweet?text=${text}&url=${url}`;
        break;
      case 'instagram':
        // Instagram doesn't support direct URL sharing
        navigator.clipboard.writeText(window.location.href);
        alert('Link copied! Share it on Instagram.');
        return;
    }
    
    if (shareUrl) {
      window.open(shareUrl, '_blank', 'width=600,height=400');
    }
    
    if (onShare) onShare(platform);
  };

  return (
    <div 
      className="relative w-full h-full bg-black"
      onMouseMove={handleMouseMove}
      onMouseLeave={() => isPlaying && setShowControls(false)}
    >
      {/* Video */}
      <video
        ref={videoRef}
        src={videoUrl}
        poster={thumbnail}
        className="w-full h-full object-contain"
        loop
        playsInline
        onClick={togglePlay}
      />

      {/* Close Button */}
      {onClose && (
        <button
          onClick={onClose}
          className="absolute top-4 left-4 z-20 w-10 h-10 bg-black/50 rounded-full flex items-center justify-center text-yellow-400 hover:bg-black/70"
        >
          <X className="w-5 h-5" />
        </button>
      )}

      {/* Play/Pause Overlay */}
      {!isPlaying && (
        <div 
          className="absolute inset-0 flex items-center justify-center bg-black/30 cursor-pointer"
          onClick={togglePlay}
        >
          <div className="w-20 h-20 bg-yellow-500/80 rounded-full flex items-center justify-center">
            <Play className="w-10 h-10 text-black ml-1" />
          </div>
        </div>
      )}

      {/* Controls */}
      <div className={`absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/90 via-black/50 to-transparent p-4 transition-opacity ${showControls ? 'opacity-100' : 'opacity-0'}`}>
        {/* Progress Bar */}
        <input
          type="range"
          value={progress}
          onChange={handleSeek}
          className="w-full h-1 bg-yellow-500/30 rounded-full appearance-none cursor-pointer mb-4"
          style={{
            background: `linear-gradient(to right, #EAB308 ${progress}%, rgba(234, 179, 8, 0.3) ${progress}%)`
          }}
        />

        {/* Control Buttons */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button
              onClick={togglePlay}
              className="w-10 h-10 bg-yellow-500 rounded-full flex items-center justify-center text-black hover:bg-yellow-400"
            >
              {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 ml-0.5" />}
            </button>
            <button
              onClick={toggleMute}
              className="w-10 h-10 bg-black/50 rounded-full flex items-center justify-center text-yellow-400 hover:bg-black/70"
            >
              {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
            </button>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2">
            <button
              onClick={onLike}
              className={`w-10 h-10 rounded-full flex items-center justify-center ${isLiked ? 'bg-red-500 text-white' : 'bg-black/50 text-yellow-400 hover:bg-black/70'}`}
            >
              <Heart className={`w-5 h-5 ${isLiked ? 'fill-current' : ''}`} />
            </button>
            <button
              onClick={onComment}
              className="w-10 h-10 bg-black/50 rounded-full flex items-center justify-center text-yellow-400 hover:bg-black/70"
            >
              <MessageCircle className="w-5 h-5" />
            </button>
            
            {/* Share Dropdown */}
            <div className="relative group">
              <button className="w-10 h-10 bg-black/50 rounded-full flex items-center justify-center text-yellow-400 hover:bg-black/70">
                <Share2 className="w-5 h-5" />
              </button>
              <div className="absolute bottom-full right-0 mb-2 hidden group-hover:flex flex-col gap-1 bg-black border border-yellow-500/30 rounded-lg p-2">
                <button
                  onClick={() => shareToSocial('facebook')}
                  className="px-3 py-2 text-sm text-yellow-100 hover:bg-yellow-500/20 rounded text-left"
                >
                  Facebook
                </button>
                <button
                  onClick={() => shareToSocial('twitter')}
                  className="px-3 py-2 text-sm text-yellow-100 hover:bg-yellow-500/20 rounded text-left"
                >
                  Twitter
                </button>
                <button
                  onClick={() => shareToSocial('instagram')}
                  className="px-3 py-2 text-sm text-yellow-100 hover:bg-yellow-500/20 rounded text-left"
                >
                  Instagram
                </button>
              </div>
            </div>

            <button
              onClick={handleFullscreen}
              className="w-10 h-10 bg-black/50 rounded-full flex items-center justify-center text-yellow-400 hover:bg-black/70"
            >
              <Maximize className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Video Info */}
        {user && (
          <div className="flex items-center gap-3 mt-3">
            <img
              src={user.avatar || '/logo.jpg'}
              alt={user.username}
              className="w-10 h-10 rounded-full border border-yellow-500/30"
            />
            <div>
              <p className="text-yellow-100 font-medium">{user.username}</p>
              {title && <p className="text-yellow-500/60 text-sm">{title}</p>}
            </div>
            <div className="ml-auto flex items-center gap-4 text-sm text-yellow-500/60">
              <span>{likes} likes</span>
              <span>{comments} comments</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
