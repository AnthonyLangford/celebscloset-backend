import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Search, Bell, MessageCircle, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useAuth } from '@/context/AuthContext';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

export const TopBar: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [showAI, setShowAI] = useState(false);
  const [aiResponse, setAiResponse] = useState<any>(null);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;

    // Demo AI response
    setAiResponse({
      answer: `Hi! I'm Nana. I can help you find products, discover celebrities, and navigate CelebsCloset. You searched for: "${searchQuery}"`,
      suggestions: ['Browse Marketplace', 'Find Celebrities', 'Watch Reels'],
      action: 'navigate',
      data: { type: 'marketplace' }
    });
    setShowAI(true);
  };

  return (
    <>
      <header className="fixed top-0 left-0 right-0 lg:left-64 bg-black/90 backdrop-blur-lg border-b border-yellow-500/20 z-40">
        <div className="flex items-center justify-between h-16 px-4">
          {/* Logo - Mobile Only */}
          <Link to="/" className="lg:hidden flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg overflow-hidden border border-yellow-500/50">
              <img src="/logo.jpg" alt="CC" className="w-full h-full object-cover" />
            </div>
            <span className="font-bold text-lg text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 to-yellow-500">
              CC
            </span>
          </Link>

          {/* Search Bar */}
          <form onSubmit={handleSearch} className="flex-1 max-w-xl mx-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-yellow-500/50" />
              <Input
                type="text"
                placeholder="Ask Nana AI anything..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-yellow-950/30 border-yellow-500/30 rounded-full text-yellow-100 placeholder:text-yellow-500/40 focus:border-yellow-400 focus:ring-yellow-400/20"
              />
            </div>
          </form>

          {/* Actions */}
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              className="relative text-yellow-500/60 hover:text-yellow-400 hover:bg-yellow-500/10"
              onClick={() => navigate('/messages')}
            >
              <MessageCircle className="w-5 h-5" />
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-gradient-to-r from-yellow-500 to-yellow-600 rounded-full text-xs flex items-center justify-center text-black font-bold">
                2
              </span>
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="relative text-yellow-500/60 hover:text-yellow-400 hover:bg-yellow-500/10"
            >
              <Bell className="w-5 h-5" />
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-gradient-to-r from-yellow-500 to-yellow-600 rounded-full text-xs flex items-center justify-center text-black font-bold">
                3
              </span>
            </Button>
            <Link to="/profile" className="hidden sm:block">
              <img
                src={user?.avatar || '/logo.jpg'}
                alt={user?.username}
                className="w-8 h-8 rounded-full border-2 border-yellow-500/50"
              />
            </Link>
          </div>
        </div>
      </header>

      {/* AI Response Dialog */}
      <Dialog open={showAI} onOpenChange={setShowAI}>
        <DialogContent className="bg-black border-yellow-500/30 text-yellow-100 max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-yellow-400">
              <Sparkles className="w-5 h-5" />
              Nana AI
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-yellow-200/80">{aiResponse?.answer}</p>
            {aiResponse?.suggestions?.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {aiResponse.suggestions.map((suggestion: string, idx: number) => (
                  <Button
                    key={idx}
                    variant="outline"
                    size="sm"
                    className="border-yellow-500/30 text-yellow-400 hover:bg-yellow-500/10"
                    onClick={() => {
                      setSearchQuery(suggestion);
                      setShowAI(false);
                    }}
                  >
                    {suggestion}
                  </Button>
                ))}
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};
