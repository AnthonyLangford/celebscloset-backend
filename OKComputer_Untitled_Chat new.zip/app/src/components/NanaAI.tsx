import React, { useState, useRef, useEffect } from 'react';
import { Mic, X, Sparkles, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

interface NanaAIProps {
  onNavigate: (path: string) => void;
}

export const NanaAI: React.FC<NanaAIProps> = ({ onNavigate }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [query, setQuery] = useState('');
  const [response, setResponse] = useState<any>(null);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const recognitionRef = useRef<any>(null);

  // Initialize speech recognition
  useEffect(() => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = true;
      recognitionRef.current.interimResults = false;
      
      recognitionRef.current.onresult = (event: any) => {
        const transcript = event.results[event.results.length - 1][0].transcript.toLowerCase();
        
        // Wake word detection
        if (transcript.includes('nana') || transcript.includes('hey nana')) {
          setIsOpen(true);
          const question = transcript.replace(/(hey\s*)?nana/i, '').trim();
          if (question) {
            setQuery(question);
            handleAsk(question);
          }
        }
      };

      recognitionRef.current.onerror = (event: any) => {
        console.error('Speech recognition error:', event.error);
      };
    }
  }, []);

  // Start listening for wake word
  const startListening = () => {
    if (recognitionRef.current) {
      setIsListening(true);
      recognitionRef.current.start();
    }
  };

  const stopListening = () => {
    if (recognitionRef.current) {
      setIsListening(false);
      recognitionRef.current.stop();
    }
  };

  const handleAsk = async (questionText: string = query) => {
    if (!questionText.trim()) return;

    try {
      const res = await fetch('/api/ai/ask', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify({ question: questionText, voiceMode: true })
      });

      const data = await res.json();
      setResponse(data);

      // Play voice response
      if (data.voiceResponse) {
        speakText(data.voiceResponse);
      }
    } catch (error) {
      console.error('Nana error:', error);
    }
  };

  const speakText = async (text: string) => {
    try {
      setIsSpeaking(true);
      
      const res = await fetch('/api/ai/speak', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify({ text })
      });

      if (res.ok) {
        const blob = await res.blob();
        const url = URL.createObjectURL(blob);
        
        if (audioRef.current) {
          audioRef.current.src = url;
          audioRef.current.play();
          audioRef.current.onended = () => setIsSpeaking(false);
        }
      } else {
        // Fallback to browser TTS
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.voice = speechSynthesis.getVoices().find(v => v.name.includes('Female')) || null;
        utterance.onend = () => setIsSpeaking(false);
        speechSynthesis.speak(utterance);
      }
    } catch (error) {
      console.error('TTS error:', error);
      setIsSpeaking(false);
    }
  };

  const handleSuggestionClick = (suggestion: string, action?: string) => {
    if (action) {
      switch (action) {
        case 'marketplace':
          onNavigate('/marketplace');
          break;
        case 'celebrities':
          onNavigate('/celebrities');
          break;
        case 'messages':
          onNavigate('/messages');
          break;
        case 'profile':
          onNavigate('/profile');
          break;
        case 'entertainment':
          onNavigate('/entertainment');
          break;
        default:
          onNavigate('/');
      }
    }
    setQuery(suggestion);
    handleAsk(suggestion);
  };

  return (
    <>
      {/* Floating Nana Button */}
      <button
        onClick={() => {
          setIsOpen(!isOpen);
          if (!isListening) startListening();
        }}
        className={`fixed bottom-24 right-4 z-50 w-14 h-14 rounded-full flex items-center justify-center transition-all ${
          isListening 
            ? 'bg-gradient-to-r from-yellow-500 to-yellow-600 animate-pulse shadow-[0_0_20px_rgba(234,179,8,0.6)]' 
            : 'bg-gradient-to-r from-yellow-600 to-yellow-500 hover:shadow-[0_0_20px_rgba(234,179,8,0.4)]'
        }`}
      >
        {isListening ? (
          <div className="flex gap-1">
            <span className="w-1 h-4 bg-black animate-bounce" />
            <span className="w-1 h-4 bg-black animate-bounce delay-100" />
            <span className="w-1 h-4 bg-black animate-bounce delay-200" />
          </div>
        ) : (
          <Sparkles className="w-6 h-6 text-black" />
        )}
      </button>

      {/* Nana Chat Panel */}
      {isOpen && (
        <div className="fixed bottom-40 right-4 z-50 w-80 md:w-96 bg-black border border-yellow-500/30 rounded-2xl shadow-[0_0_40px_rgba(234,179,8,0.2)] overflow-hidden">
          {/* Header */}
          <div className="flex items-center justify-between p-4 bg-gradient-to-r from-yellow-950/50 to-black border-b border-yellow-500/20">
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-full bg-gradient-to-r from-yellow-500 to-yellow-600 flex items-center justify-center ${isSpeaking ? 'animate-pulse' : ''}`}>
                <Sparkles className="w-5 h-5 text-black" />
              </div>
              <div>
                <h3 className="font-bold text-yellow-100">Nana AI</h3>
                <p className="text-xs text-yellow-500/60">
                  {isListening ? 'Listening for "Hey Nana"...' : 'Say "Hey Nana" to activate'}
                </p>
              </div>
            </div>
            <button 
              onClick={() => setIsOpen(false)}
              className="text-yellow-500/60 hover:text-yellow-400"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Response Area */}
          <div className="p-4 max-h-64 overflow-y-auto">
            {response ? (
              <div className="space-y-3">
                <div className="bg-yellow-950/30 p-3 rounded-xl border border-yellow-500/20">
                  <p className="text-yellow-100 text-sm">{response.answer}</p>
                </div>
                
                {response.suggestions?.length > 0 && (
                  <div className="flex flex-wrap gap-2">
                    {response.suggestions.map((suggestion: string, idx: number) => (
                      <button
                        key={idx}
                        onClick={() => handleSuggestionClick(suggestion, response.action)}
                        className="px-3 py-1.5 bg-yellow-500/20 text-yellow-400 text-xs rounded-full border border-yellow-500/30 hover:bg-yellow-500/30"
                      >
                        {suggestion}
                      </button>
                    ))}
                  </div>
                )}

                {response.data?.celebrities && (
                  <div className="space-y-2">
                    <p className="text-xs text-yellow-500/60">Featured Celebrities:</p>
                    {response.data.celebrities.slice(0, 3).map((celeb: any) => (
                      <button
                        key={celeb._id}
                        onClick={() => onNavigate(`/celebrity/${celeb.username}`)}
                        className="w-full flex items-center gap-2 p-2 bg-yellow-950/20 rounded-lg hover:bg-yellow-500/10"
                      >
                        <img src={celeb.image} alt={celeb.name} className="w-8 h-8 rounded-full object-cover" />
                        <div className="text-left">
                          <p className="text-sm text-yellow-100">{celeb.name}</p>
                          <p className="text-xs text-yellow-500/60">@{celeb.username}</p>
                        </div>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            ) : (
              <div className="text-center py-6 text-yellow-500/50">
                <Sparkles className="w-12 h-12 mx-auto mb-3 opacity-50" />
                <p className="text-sm">Hi! I'm Nana, your AI assistant.</p>
                <p className="text-xs mt-1">Ask me anything or say "Hey Nana"</p>
              </div>
            )}
          </div>

          {/* Input Area */}
          <div className="p-4 border-t border-yellow-500/20">
            <div className="flex gap-2">
              <Input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleAsk()}
                placeholder="Ask Nana anything..."
                className="flex-1 bg-yellow-950/30 border-yellow-500/30 text-yellow-100 placeholder:text-yellow-500/40"
              />
              <Button
                onClick={() => handleAsk()}
                className="bg-gradient-to-r from-yellow-600 to-yellow-500 text-black"
              >
                <Send className="w-4 h-4" />
              </Button>
              <Button
                onClick={() => isListening ? stopListening() : startListening()}
                variant="outline"
                className={`border-yellow-500/30 ${isListening ? 'bg-yellow-500/20 text-yellow-400' : 'text-yellow-500/60'}`}
              >
                <Mic className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Hidden audio element */}
          <audio ref={audioRef} className="hidden" />
        </div>
      )}
    </>
  );
};
