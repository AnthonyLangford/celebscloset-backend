import axios from 'axios';
import type { User, Post, Product, Message, Conversation, Reel, Event, Order, Category, AIResponse } from '@/types';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json'
  }
});

export const setAuthToken = (token: string | null) => {
  if (token) {
    api.defaults.headers.common['Authorization'] = `Bearer ${token}`;
  } else {
    delete api.defaults.headers.common['Authorization'];
  }
};

// Auth
export const login = async (email: string, password: string): Promise<{ token: string; user: User }> => {
  const response = await api.post('/auth/login', { email, password });
  return response.data;
};

export const ceoLogin = async (masterKey: string): Promise<{ token: string; user: User }> => {
  const response = await api.post('/auth/ceo-login', { masterKey });
  return response.data;
};

export const register = async (data: { username: string; email: string; password: string; fullName: string }): Promise<{ token: string; user: User }> => {
  const response = await api.post('/auth/register', data);
  return response.data;
};

// Users
export const getCurrentUser = async (): Promise<User> => {
  const response = await api.get('/users/me');
  return response.data;
};

export const getUser = async (username: string): Promise<{ user: User; posts: Post[]; products: Product[] }> => {
  const response = await api.get(`/users/${username}`);
  return response.data;
};

export const getCelebrities = async (): Promise<User[]> => {
  const response = await api.get('/users/celebrities/all');
  return response.data;
};

export const followUser = async (userId: string): Promise<{ following: string[] }> => {
  const response = await api.post(`/users/${userId}/follow`);
  return response.data;
};

export const updateProfile = async (data: Partial<User>): Promise<User> => {
  const response = await api.patch('/users/me', data);
  return response.data;
};

export const searchUsers = async (query: string): Promise<User[]> => {
  const response = await api.get(`/users/search/query?q=${encodeURIComponent(query)}`);
  return response.data;
};

// Posts
export const getFeed = async (): Promise<Post[]> => {
  const response = await api.get('/posts/feed');
  return response.data;
};

export const getStories = async (): Promise<Post[]> => {
  const response = await api.get('/posts/stories');
  return response.data;
};

export const createPost = async (data: Partial<Post>): Promise<Post> => {
  const response = await api.post('/posts', data);
  return response.data;
};

export const likePost = async (postId: string): Promise<Post> => {
  const response = await api.post(`/posts/${postId}/like`);
  return response.data;
};

export const commentOnPost = async (postId: string, content: string): Promise<Post> => {
  const response = await api.post(`/posts/${postId}/comment`, { content });
  return response.data;
};

export const sharePost = async (postId: string): Promise<Post> => {
  const response = await api.post(`/posts/${postId}/share`);
  return response.data;
};

// Products
export const getProducts = async (category?: string, search?: string): Promise<Product[]> => {
  const params = new URLSearchParams();
  if (category) params.append('category', category);
  if (search) params.append('search', search);
  const response = await api.get(`/products?${params.toString()}`);
  return response.data;
};

export const getProduct = async (id: string): Promise<Product> => {
  const response = await api.get(`/products/${id}`);
  return response.data;
};

export const createProduct = async (data: Partial<Product>): Promise<Product> => {
  const response = await api.post('/products', data);
  return response.data;
};

export const placeBid = async (productId: string, amount: number): Promise<Product> => {
  const response = await api.post(`/products/${productId}/bid`, { amount });
  return response.data;
};

export const buyProduct = async (productId: string): Promise<{ order: Order; product: Product }> => {
  const response = await api.post(`/products/${productId}/buy`);
  return response.data;
};

export const getCategories = async (): Promise<Category[]> => {
  const response = await api.get('/products/categories/all');
  return response.data;
};

// Messages
export const getConversations = async (): Promise<Conversation[]> => {
  const response = await api.get('/messages/conversations');
  return response.data;
};

export const getMessages = async (userId: string): Promise<Message[]> => {
  const response = await api.get(`/messages/${userId}`);
  return response.data;
};

export const sendMessage = async (receiverId: string, content: string, media?: string, mediaType?: string): Promise<Message> => {
  const response = await api.post('/messages', { receiverId, content, media, mediaType });
  return response.data;
};

// Reels
export const getReels = async (): Promise<Reel[]> => {
  const response = await api.get('/reels');
  return response.data;
};

export const getLiveReels = async (): Promise<Reel[]> => {
  const response = await api.get('/reels/live');
  return response.data;
};

export const createReel = async (data: Partial<Reel>): Promise<Reel> => {
  const response = await api.post('/reels', data);
  return response.data;
};

export const likeReel = async (reelId: string): Promise<Reel> => {
  const response = await api.post(`/reels/${reelId}/like`);
  return response.data;
};

export const viewReel = async (reelId: string): Promise<Reel> => {
  const response = await api.post(`/reels/${reelId}/view`);
  return response.data;
};

// Events
export const getEvents = async (): Promise<Event[]> => {
  const response = await api.get('/events');
  return response.data;
};

export const getUpcomingEvents = async (): Promise<Event[]> => {
  const response = await api.get('/events/upcoming');
  return response.data;
};

export const createEvent = async (data: Partial<Event>): Promise<Event> => {
  const response = await api.post('/events', data);
  return response.data;
};

export const buyTicket = async (eventId: string): Promise<{ order: Order; event: Event }> => {
  const response = await api.post(`/events/${eventId}/buy-ticket`);
  return response.data;
};

// AI
export const askAI = async (question: string): Promise<AIResponse> => {
  const response = await api.post('/ai/ask', { question });
  return response.data;
};

export const getAISuggestions = async (): Promise<{ text: string; icon: string }[]> => {
  const response = await api.get('/ai/suggestions');
  return response.data;
};

// Admin
export const getAdminStats = async (): Promise<{ stats: any; recentOrders: Order[] }> => {
  const response = await api.get('/admin/stats');
  return response.data;
};

export const getAdminUsers = async (): Promise<User[]> => {
  const response = await api.get('/admin/users');
  return response.data;
};

export const verifyUser = async (userId: string): Promise<User> => {
  const response = await api.post(`/admin/users/${userId}/verify`);
  return response.data;
};

export const makeCelebrity = async (userId: string): Promise<User> => {
  const response = await api.post(`/admin/users/${userId}/celebrity`);
  return response.data;
};

export const getAdminProducts = async (): Promise<Product[]> => {
  const response = await api.get('/admin/products');
  return response.data;
};

export const removeProduct = async (productId: string): Promise<void> => {
  await api.delete(`/admin/products/${productId}`);
};

// Payments
export const createPaymentIntent = async (orderId: string): Promise<{ clientSecret: string }> => {
  const response = await api.post('/payments/create-intent', { orderId });
  return response.data;
};

export default api;
